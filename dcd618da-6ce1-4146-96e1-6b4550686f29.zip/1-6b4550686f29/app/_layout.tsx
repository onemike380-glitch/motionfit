
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Platform, SafeAreaView, View } from 'react-native';
import { ThemeProvider, useTheme } from '../styles/commonStyles';
import { useEffect } from 'react';
import { setupErrorLogging } from '../utils/errorLogger';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { useFonts, Roboto_400Regular, Roboto_700Bold } from '@expo-google-fonts/roboto';

const STORAGE_KEY = 'emulated_device';

function RootContent() {
  const insets = useSafeAreaInsets();
  const { commonStyles, mode } = useTheme();

  return (
    <SafeAreaView
      style={[
        commonStyles.wrapper,
        {
          paddingTop: insets.top,
          paddingBottom: insets.bottom,
          paddingLeft: insets.left,
          paddingRight: insets.right,
        },
      ]}
    >
      <StatusBar style={mode === 'dark' ? 'light' : 'dark'} />
      <Stack screenOptions={{ headerShown: false, animation: 'default' }} />
    </SafeAreaView>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Roboto_400Regular,
    Roboto_700Bold,
  });

  useEffect(() => {
    setupErrorLogging();
    // emulate parameter store for web only
    if (Platform.OS === 'web') {
      try {
        const url = new URL(window.location.href);
        const emulate = url.searchParams.get('emulate');
        if (emulate) localStorage.setItem(STORAGE_KEY, emulate);
      } catch (e) {
        console.log('No emulate param present');
      }
    }
  }, []);

  if (!fontsLoaded && !fontError) {
    return (
      <SafeAreaProvider>
        <GestureHandlerRootView style={{ flex: 1 }}>
          <ThemeProvider>
            <View style={{ flex: 1 }}>
              <RootContent />
            </View>
          </ThemeProvider>
        </GestureHandlerRootView>
      </SafeAreaProvider>
    );
  }

  return (
    <SafeAreaProvider>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <ThemeProvider>
          <RootContent />
        </ThemeProvider>
      </GestureHandlerRootView>
    </SafeAreaProvider>
  );
}
