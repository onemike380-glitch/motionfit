
import { ScrollView, View, Text, StyleSheet } from 'react-native';
import { useTheme } from '../../styles/commonStyles';
import DoughnutChart from '../../components/DoughnutChart';
import Icon from '../../components/Icon';
import Button from '../../components/Button';
import { useRouter } from 'expo-router';
import { usePedometer } from '../../hooks/usePedometer';
import { useMotion } from '../../hooks/useMotion';
import React from 'react';
import { useUserProfile } from '../../hooks/useUserProfile';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function HomeScreen() {
  const { colors, commonStyles } = useTheme();
  const router = useRouter();
  const { profile } = useUserProfile();
  const insets = useSafeAreaInsets();

  // Live motion and pedometer
  const pedo = usePedometer(true);
  const motion = useMotion(true, 300);

  const stepsGoal = 8000;
  const stepProgress = Math.min(1, pedo.totalSteps / stepsGoal);

  const calories = pedo.caloriesKcal;
  const goal = 200; // default daily kcal goal
  const moveProgress = Math.min(1, calories / goal);

  const greetingName = profile?.name ? profile.name.split(' ')[0] : 'there';
  const bottomPad = 24 + insets.bottom + 16;

  return (
    <View style={commonStyles.container}>
      <ScrollView
        contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 12, paddingBottom: bottomPad }}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={[commonStyles.h1, { marginBottom: 4 }]}>Hi, {greetingName}</Text>
        <Text style={[commonStyles.subText, { marginBottom: 10, color: colors.muted }]}>Summary</Text>

        <View style={[styles.cardLarge(colors)]}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <DoughnutChart
              progress={moveProgress}
              color={colors.highlight}
              label="Move"
              valueText={`${Math.round(calories)}/${goal} cal`}
              subText="Today"
              size={160}
              thickness={18}
            />
            <View style={{ marginLeft: 16, flex: 1 }}>
              <Text style={[commonStyles.h2, { color: colors.text }]}>Activity Ring</Text>
              <Text style={[commonStyles.subText, { marginTop: 4, color: colors.muted }]}>
                Close your ring by staying active.
              </Text>

              <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
                <Button text="Exercises" onPress={() => router.push('/(tabs)/exercises')} style={{ flex: 1 }} />
                <Button
                  text="Awards"
                  variant="outline"
                  onPress={() => router.push('/(tabs)/profile')}
                  style={{ flex: 1 }}
                />
              </View>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <Button
                  text="Track"
                  variant="secondary"
                  onPress={() => router.push('/(tabs)/motion')}
                  style={{ flex: 1 }}
                />
              </View>
            </View>
          </View>
        </View>

        <View style={commonStyles.row}>
          <View style={[commonStyles.card, styles.flexCard]}>
            <View style={styles.cardHeader}>
              <Text style={[styles.cardTitle(colors)]}>Step Distance</Text>
              <Icon name="chevron-forward" size={18} color={colors.highlight} />
            </View>
            <Text style={[styles.bigNumber(colors)]}>{pedo.distanceMiles.toFixed(2)} mi</Text>
            <View style={[styles.sparkline(colors)]} />
          </View>

          <View style={[commonStyles.card, styles.flexCard]}>
            <View style={styles.cardHeader}>
              <Text style={[styles.cardTitle(colors)]}>Step Count</Text>
              <Icon name="chevron-forward" size={18} color={colors.accent} />
            </View>
            <Text style={[styles.bigNumberAlt]}>{pedo.totalSteps}</Text>
            <View style={[styles.sparkline(colors)]} />
          </View>
        </View>

        <View style={[commonStyles.card, { marginTop: 8 }]}>
          <View style={styles.cardHeader}>
            <Text style={[styles.cardTitle(colors)]}>Accelerometer</Text>
            <Icon name="pulse-outline" size={18} color={colors.highlight} />
          </View>
          <Text style={{ color: colors.text, marginTop: 6 }}>
            mag: {motion.accelMag.toFixed(2)} (x: {motion.accel.x.toFixed(2)} y: {motion.accel.y.toFixed(2)} z:{' '}
            {motion.accel.z.toFixed(2)})
          </Text>
        </View>

        <View style={[commonStyles.card, { marginTop: 8 }]}>
          <View style={styles.cardHeader}>
            <Text style={[styles.cardTitle(colors)]}>Gyroscope</Text>
            <Icon name="compass-outline" size={18} color={colors.accent} />
          </View>
          <Text style={{ color: colors.text, marginTop: 6 }}>
            mag: {motion.gyroMag.toFixed(2)} (x: {motion.gyro.x.toFixed(2)} y: {motion.gyro.y.toFixed(2)} z:{' '}
            {motion.gyro.z.toFixed(2)})
          </Text>
        </View>

        <View style={[styles.cardLarge(colors), { marginTop: 8 }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <DoughnutChart
              progress={stepProgress}
              color={colors.accent}
              label="Steps"
              valueText={`${pedo.totalSteps}/${stepsGoal}`}
              subText="Today"
              size={140}
              thickness={16}
            />
            <View style={{ marginLeft: 16, flex: 1 }}>
              <Text style={[commonStyles.h2, { color: colors.text }]}>Steps Progress</Text>
              <Text style={[commonStyles.subText, { marginTop: 4, color: colors.muted }]}>
                Track your daily steps goal.
              </Text>
            </View>
          </View>
        </View>

        <View style={{ height: 16 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  cardLarge: (colors: any) => ({
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    borderColor: colors.border,
    borderWidth: 1,
    boxShadow: '0px 10px 20px rgba(16, 18, 19, 0.06)',
    marginBottom: 8,
  }),
  flexCard: {
    flex: 1,
  },
  cardHeader: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cardTitle: (colors: any) => ({
    fontSize: 14,
    fontWeight: '700',
    color: colors.text,
  }),
  bigNumber: (colors: any) => ({
    fontSize: 28,
    fontWeight: '700',
    color: colors.accent,
    marginTop: 6,
  }),
  bigNumberAlt: {
    fontSize: 28,
    fontWeight: '700',
    color: '#8B5CF6',
    marginTop: 6,
  },
  sparkline: (colors: any) => ({
    marginTop: 10,
    height: 32,
    backgroundColor: colors.backgroundAlt,
    borderRadius: 8,
  }),
  awardOuter: (colors: any) => ({
    width: 52,
    height: 52,
    borderRadius: 26,
    borderWidth: 2,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  }),
  awardInner: (colors: any) => ({
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: colors.border,
  }),
  awardTitle: (colors: any) => ({
    fontSize: 14,
    color: colors.text,
    fontWeight: '700',
  }),
});
