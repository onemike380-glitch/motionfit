
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, Platform } from 'react-native';
import { useTheme } from '../../styles/commonStyles';
import { useMotion } from '../../hooks/useMotion';
import { usePedometer } from '../../hooks/usePedometer';
import DoughnutChart from '../../components/DoughnutChart';
import Button from '../../components/Button';
import {
  getActiveMsToday,
  setDailySteps,
  loadDailyStats,
  addWaterMl,
  addSleepMin,
  addCalorieIntake,
} from '../../utils/activityStorage';
import { useLiveActivity } from '../../hooks/useLiveActivity';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

function formatDuration(ms: number) {
  const totalSec = Math.floor(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

function formatMinutes(min: number) {
  const h = Math.floor(min / 60);
  const m = min % 60;
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

export default function MotionScreen() {
  const { colors, commonStyles } = useTheme();
  const [enabled, setEnabled] = useState(true);
  const insets = useSafeAreaInsets();

  const motion = useMotion(enabled, 250);
  const pedo = usePedometer(enabled);
  const live = useLiveActivity(enabled);

  const stepsGoal = 8000;
  const stepProgress = Math.min(1, pedo.totalSteps / stepsGoal);

  const [activeTodayMs, setActiveTodayMs] = useState(0);

  // Wellness state
  const [waterMl, setWaterMlState] = useState(0);
  const [sleepMin, setSleepMinState] = useState(0);
  const [calorieIntakeKcal, setCalorieIntakeState] = useState(0);

  // Wellness goals
  const WATER_GOAL_ML = 2000;
  const SLEEP_GOAL_MIN = 8 * 60;
  const CALORIE_GOAL_KCAL = 2200;

  // Foreground: update stored steps to today's value
  useEffect(() => {
    if (enabled) {
      setDailySteps(pedo.totalSteps).catch((e) => console.log('setDailySteps error', e));
    }
  }, [pedo.totalSteps, enabled]);

  // Poll active today every few seconds for UI
  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    const load = async () => {
      const v = await getActiveMsToday();
      setActiveTodayMs(v);
      try {
        const stats = await loadDailyStats(new Date().toISOString().slice(0, 10));
        setWaterMlState(stats.waterMl ?? 0);
        setSleepMinState(stats.sleepMin ?? 0);
        setCalorieIntakeState(stats.calorieIntakeKcal ?? 0);
      } catch (e) {
        console.log('loadDailyStats in motion error', e);
      }
    };
    load();
    timer = setInterval(load, 5000);
    return () => {
      if (timer) clearInterval(timer);
    };
  }, []);

  const activeWithLive = activeTodayMs + (live.active ? live.elapsedMs : 0);
  const bottomPad = 24 + insets.bottom + 16;

  const handleAddWater = async (ml: number) => {
    await addWaterMl(ml);
    setWaterMlState((v) => v + ml);
  };
  const handleAddSleep = async (min: number) => {
    await addSleepMin(min);
    setSleepMinState((v) => v + min);
  };
  const handleAddCalories = async (kcal: number) => {
    await addCalorieIntake(kcal);
    setCalorieIntakeState((v) => v + kcal);
  };

  return (
    <View style={commonStyles.container}>
      <ScrollView
        contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 12, paddingBottom: bottomPad }}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={[{ fontSize: 28, fontWeight: '700', color: colors.text, marginBottom: 10 }]}>Track</Text>

        <View style={styles.card(colors)}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <DoughnutChart
              progress={stepProgress}
              color={colors.highlight}
              label="Steps"
              valueText={`${pedo.totalSteps}/${stepsGoal}`}
              subText="Today"
              size={150}
              thickness={16}
            />
            <View style={{ marginLeft: 16, flex: 1 }}>
              <Text style={[styles.title(colors)]}>Live Activity</Text>
              <Text style={{ color: colors.muted, fontSize: 12 }}>
                Auto-start when moving. Sensors {enabled ? 'on' : 'off'} {Platform.OS === 'web' ? '(web sensors limited)' : ''}
              </Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 8 }}>
                <Text style={{ color: colors.text, fontWeight: '600' }}>Enable Tracking</Text>
                <Switch
                  style={{ marginLeft: 10 }}
                  value={enabled}
                  onValueChange={setEnabled}
                  trackColor={{ false: colors.border, true: colors.highlight }}
                  thumbColor="#fff"
                />
              </View>
            </View>
          </View>

          <View style={{ marginTop: 12, flexDirection: 'row', gap: 12 }}>
            <View style={[styles.metric(colors), { flex: 1 }]}>
              <Text style={styles.metricLabel(colors)}>Live Timer</Text>
              <Text style={styles.metricValue(colors)}>
                {live.active ? formatDuration(live.elapsedMs) : 'Waiting for movement'}
              </Text>
            </View>
            <View style={[styles.metric(colors), { flex: 1 }]}>
              <Text style={styles.metricLabel(colors)}>Active Today</Text>
              <Text style={styles.metricValue(colors)}>{formatDuration(activeWithLive)}</Text>
            </View>
          </View>
        </View>

        {/* Wellness Trackers */}
        <View style={styles.card(colors)}>
          <Text style={styles.title(colors)}>Wellness</Text>

          <View style={{ flexDirection: 'row', gap: 12, marginTop: 10 }}>
            <View style={[styles.metric(colors), { flex: 1, alignItems: 'center' }]}>
              <DoughnutChart
                progress={Math.min(1, waterMl / WATER_GOAL_ML)}
                color={colors.accent}
                label="Water"
                valueText={`${(waterMl / 1000).toFixed(1)}/${(WATER_GOAL_ML / 1000).toFixed(1)} L`}
                subText="Today"
                size={120}
                thickness={14}
              />
              <View style={{ flexDirection: 'row', gap: 8, marginTop: 8, width: '100%' }}>
                <Button text="+250ml" variant="outline" onPress={() => handleAddWater(250)} style={{ flex: 1 }} />
                <Button text="+500ml" onPress={() => handleAddWater(500)} style={{ flex: 1 }} />
              </View>
            </View>

            <View style={[styles.metric(colors), { flex: 1, alignItems: 'center' }]}>
              <DoughnutChart
                progress={Math.min(1, sleepMin / SLEEP_GOAL_MIN)}
                color={colors.highlight}
                label="Sleep"
                valueText={`${formatMinutes(sleepMin)}/8h`}
                subText="Logged"
                size={120}
                thickness={14}
              />
              <View style={{ flexDirection: 'row', gap: 8, marginTop: 8, width: '100%' }}>
                <Button text="+15m" variant="outline" onPress={() => handleAddSleep(15)} style={{ flex: 1 }} />
                <Button text="+30m" onPress={() => handleAddSleep(30)} style={{ flex: 1 }} />
              </View>
            </View>
          </View>

          <View style={{ flexDirection: 'row', gap: 12 }}>
            <View style={[styles.metric(colors), { flex: 1, alignItems: 'center' }]}>
              <DoughnutChart
                progress={Math.min(1, calorieIntakeKcal / CALORIE_GOAL_KCAL)}
                color="#8B5CF6"
                label="Calories"
                valueText={`${Math.round(calorieIntakeKcal)}/${CALORIE_GOAL_KCAL}`}
                subText="Intake"
                size={120}
                thickness={14}
              />
              <View style={{ flexDirection: 'row', gap: 8, marginTop: 8, width: '100%' }}>
                <Button text="+100" variant="outline" onPress={() => handleAddCalories(100)} style={{ flex: 1 }} />
                <Button text="+300" onPress={() => handleAddCalories(300)} style={{ flex: 1 }} />
              </View>
            </View>
          </View>
        </View>

        <View style={[styles.card(colors)]}>
          <Text style={styles.title(colors)}>Accelerometer</Text>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 6 }}>
            <Text style={styles.data(colors)}>x: {motion.accel.x.toFixed(2)}</Text>
            <Text style={styles.data(colors)}>y: {motion.accel.y.toFixed(2)}</Text>
            <Text style={styles.data(colors)}>z: {motion.accel.z.toFixed(2)}</Text>
          </View>
          <View style={styles.divider(colors)} />
          <Text style={styles.data(colors)}>magnitude: {motion.accelMag.toFixed(2)}</Text>
        </View>

        <View style={[styles.card(colors)]}>
          <Text style={styles.title(colors)}>Gyroscope</Text>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 6 }}>
            <Text style={styles.data(colors)}>x: {motion.gyro.x.toFixed(2)}</Text>
            <Text style={styles.data(colors)}>y: {motion.gyro.y.toFixed(2)}</Text>
            <Text style={styles.data(colors)}>z: {motion.gyro.z.toFixed(2)}</Text>
          </View>
          <View style={styles.divider(colors)} />
          <Text style={styles.data(colors)}>magnitude: {motion.gyroMag.toFixed(2)}</Text>
        </View>

        <View style={[styles.card(colors)]}>
          <Text style={styles.title(colors)}>Tip</Text>
          <Text style={{ color: colors.muted }}>
            Keep the app open to track live activity. Background fetch keeps steps updating even when the app is not on screen.
          </Text>
        </View>

        <Button text={enabled ? 'Pause Tracking' : 'Resume Tracking'} onPress={() => setEnabled((v) => !v)} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  card: (colors: any) => ({
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    borderColor: colors.border,
    borderWidth: 1,
    boxShadow: '0px 10px 20px rgba(16, 18, 19, 0.06)',
    marginBottom: 12,
  }),
  title: (colors: any) => ({
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
  }),
  data: (colors: any) => ({
    color: colors.text,
    fontWeight: '600',
  }),
  divider: (colors: any) => ({
    height: 1,
    width: '100%',
    backgroundColor: colors.border,
    marginVertical: 8,
  }),
  metric: (colors: any) => ({
    flex: 1,
    paddingVertical: 12,
    backgroundColor: colors.card,
    borderRadius: 16,
    paddingHorizontal: 12,
    borderColor: colors.border,
    borderWidth: 1,
    boxShadow: '0px 10px 20px rgba(16, 18, 19, 0.06)',
    marginBottom: 12,
  }),
  metricLabel: (colors: any) => ({
    fontSize: 12,
    color: colors.muted,
    marginBottom: 2,
  }),
  metricValue: (colors: any) => ({
    fontSize: 18,
    color: colors.text,
    fontWeight: '700',
  }),
});
