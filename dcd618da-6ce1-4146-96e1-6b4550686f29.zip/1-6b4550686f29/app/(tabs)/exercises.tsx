
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Animated, Easing, Pressable } from 'react-native';
import { useTheme } from '../../styles/commonStyles';
import Button from '../../components/Button';
import * as Haptics from 'expo-haptics';
import Icon from '../../components/Icon';
import { useRouter } from 'expo-router';
import { logExercise } from '../../utils/activityStorage';
import { useUserProfile } from '../../hooks/useUserProfile';
import {
  ALL_EXERCISES,
  Exercise,
  exerciseLabels,
  getExerciseRecommendations,
  getIntensity,
} from '../../data/exercises';

export default function ExercisesScreen() {
  const { colors, commonStyles } = useTheme();
  const router = useRouter();
  const { profile } = useUserProfile();

  const age = profile?.age ?? null;
  const conditions = profile?.conditions ?? null;

  const rec = useMemo(() => getExerciseRecommendations(age ?? undefined, conditions ?? undefined), [age, conditions]);

  // Order: recommended first, then caution, then avoid
  const library: Exercise[] = useMemo(() => {
    const pref = [...rec.recommended, ...rec.caution, ...ALL_EXERCISES.filter((e) => !rec.recommended.includes(e) && !rec.caution.includes(e))];
    // remove duplicates while preserving order
    const seen = new Set<Exercise>();
    return pref.filter((e) => {
      if (seen.has(e)) return false;
      seen.add(e);
      return true;
    });
  }, [rec]);

  const [current, setCurrent] = useState<Exercise>(library[0] || 'jumping-jacks');
  useEffect(() => {
    // When recommendations change (profile change), reset selection to the first recommended if available
    const next = rec.recommended[0] ?? library[0] ?? 'jumping-jacks';
    setCurrent(next);
  }, [rec, library]);

  const [running, setRunning] = useState(false);
  const [reps, setReps] = useState(0);
  const [durationMs, setDurationMs] = useState(0);

  const armRotation = useRef(new Animated.Value(0)).current;
  const pushup = useRef(new Animated.Value(0)).current;
  const squat = useRef(new Animated.Value(0)).current;
  const kneeAlt = useRef(new Animated.Value(0)).current;
  const lungeAlt = useRef(new Animated.Value(0)).current;

  // Duration ticker
  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    if (running) {
      timer = setInterval(() => setDurationMs((ms) => ms + 1000), 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [running]);

  useEffect(() => {
    if (!running) {
      armRotation.stopAnimation();
      pushup.stopAnimation();
      squat.stopAnimation();
      kneeAlt.stopAnimation();
      lungeAlt.stopAnimation();
      return;
    }

    if (current === 'jumping-jacks') {
      Animated.loop(
        Animated.sequence([
          Animated.timing(armRotation, {
            toValue: 1,
            duration: 400,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
          Animated.timing(armRotation, {
            toValue: 0,
            duration: 400,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
        ])
      ).start();
    }

    if (current === 'push-ups') {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pushup, {
            toValue: 1,
            duration: 500,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
          Animated.timing(pushup, {
            toValue: 0,
            duration: 500,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
        ])
      ).start();
    }

    if (current === 'squats') {
      Animated.loop(
        Animated.sequence([
          Animated.timing(squat, {
            toValue: 1,
            duration: 450,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
          Animated.timing(squat, {
            toValue: 0,
            duration: 450,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
        ])
      ).start();
    }

    if (current === 'high-knees') {
      Animated.loop(
        Animated.sequence([
          Animated.timing(kneeAlt, {
            toValue: 1,
            duration: 350,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
          Animated.timing(kneeAlt, {
            toValue: 0,
            duration: 350,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
        ])
      ).start();
    }

    if (current === 'lunges') {
      Animated.loop(
        Animated.sequence([
          Animated.timing(lungeAlt, {
            toValue: 1,
            duration: 550,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
          Animated.timing(lungeAlt, {
            toValue: 0,
            duration: 550,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
        ])
      ).start();
    }

    const repTimer = setInterval(() => {
      if (current === 'plank') {
        setReps((r) => r);
      } else {
        setReps((r) => r + 1);
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => console.log('Haptics error'));
      }
    }, 1200);

    return () => {
      clearInterval(repTimer);
    };
  }, [running, current, armRotation, pushup, squat, kneeAlt, lungeAlt]);

  const start = () => {
    setReps(0);
    setDurationMs(0);
    setRunning(true);
  };

  const stop = async () => {
    setRunning(false);
    try {
      await logExercise({
        type: current,
        reps: current === 'plank' ? null : reps,
        durationMs,
      });
    } catch (e) {
      console.log('logExercise error', e);
    }
  };

  const armRotateInterpolate = armRotation.interpolate({
    inputRange: [0, 1],
    outputRange: ['-45deg', '45deg'],
  });

  const pushupTranslateY = pushup.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 14],
  });

  const squatTranslateY = squat.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 18],
  });

  const kneeLeft = kneeAlt.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -16],
  });

  const kneeRight = kneeAlt.interpolate({
    inputRange: [0, 1],
    outputRange: [-16, 0],
  });

  const lungeLeft = lungeAlt.interpolate({
    inputRange: [0, 1],
    outputRange: [0, -12],
  });

  const lungeRight = lungeAlt.interpolate({
    inputRange: [0, 1],
    outputRange: [-12, 0],
  });

  const isTimeBased = current === 'plank';
  const headerRight = isTimeBased ? `${Math.floor(durationMs / 1000)}s` : `Reps: ${reps}`;

  const isAvoid = rec.avoid.includes(current);
  const isCaution = rec.caution.includes(current);
  const isRecommended = rec.recommended.includes(current);

  const intensity = getIntensity(current);
  const calTip =
    intensity === 'high'
      ? 'Approx. 8-14 cal/min'
      : intensity === 'moderate'
      ? 'Approx. 6-10 cal/min'
      : 'Approx. 4-7 cal/min';

  const tipSets =
    current === 'plank' ? 'Try 3 x 30–60s' : current === 'push-ups' ? 'Try 3 x 8–12 reps' : 'Try 3 x 12–15 reps';

  return (
    <View style={commonStyles.container}>
      <ScrollView
        contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 12, paddingBottom: 24 }}
        keyboardShouldPersistTaps="handled"
      >
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: 6 }}>
          <Button text="Summary" variant="outline" onPress={() => router.push('/(tabs)/index')} style={{ flex: 1 }} />
          <Button text="Track" variant="secondary" onPress={() => router.push('/(tabs)/motion')} style={{ flex: 1 }} />
        </View>

        <Text style={[{ fontSize: 28, fontWeight: '700', color: colors.text, marginBottom: 4 }]}>Exercises</Text>
        <Text style={{ fontSize: 12, color: colors.muted, marginBottom: 8 }}>
          Age group: {rec.category[0].toUpperCase() + rec.category.slice(1)}
          {profile?.name ? ` · ${profile.name}` : ''}
        </Text>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
          {library.map((ex) => {
            const chipAvoid = rec.avoid.includes(ex);
            const chipCaution = rec.caution.includes(ex);
            const chipRecommended = rec.recommended.includes(ex);
            return (
              <Pressable
                key={ex}
                onPress={() => {
                  setCurrent(ex);
                  setReps(0);
                  setDurationMs(0);
                  setRunning(false);
                }}
                style={({ pressed }) => [
                  styles.chip(colors),
                  {
                    borderColor: chipAvoid
                      ? colors.danger
                      : current === ex
                      ? colors.accent
                      : chipRecommended
                      ? colors.highlight
                      : colors.border,
                    opacity: pressed ? 0.85 : 1,
                  },
                ]}
              >
                <Text style={styles.chipText(colors)}>
                  {exerciseLabels[ex]}
                  {chipAvoid ? ' ✕' : chipCaution ? ' !' : chipRecommended ? ' ✓' : ''}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>

        <View style={styles.stageCard(colors)}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={styles.stageTitle(colors)}>{exerciseLabels[current]}</Text>
            <Text
              style={{
                fontSize: 13,
                color: isAvoid ? colors.danger : isRecommended ? colors.highlight : colors.muted,
                fontWeight: '700',
              }}
            >
              {isAvoid ? 'Not recommended' : isRecommended ? 'Recommended' : isCaution ? 'Caution' : 'Neutral'}
            </Text>
          </View>

          <View style={styles.animStage(colors)}>
            {current === 'jumping-jacks' ? (
              <View style={styles.figure}>
                <View style={[styles.head, { backgroundColor: colors.text }]} />
                <Animated.View
                  style={[styles.arm, { left: 18, backgroundColor: colors.text, transform: [{ rotate: armRotateInterpolate }] }]}
                />
                <Animated.View
                  style={[
                    styles.arm,
                    { right: 18, backgroundColor: colors.text, transform: [{ rotate: armRotateInterpolate }, { scaleX: -1 }] },
                  ]}
                />
                <View style={[styles.body, { backgroundColor: colors.text }]} />
                <View style={[styles.legLeft, { backgroundColor: colors.text }]} />
                <View style={[styles.legRight, { backgroundColor: colors.text }]} />
              </View>
            ) : current === 'push-ups' ? (
              <Animated.View style={[styles.pushupFigure, { transform: [{ translateY: pushupTranslateY }] }]}>
                <View style={[styles.pushupArm, { backgroundColor: colors.text }]} />
                <View style={[styles.pushupBody, { backgroundColor: colors.text }]} />
                <View style={[styles.pushupLegs, { backgroundColor: colors.text }]} />
              </Animated.View>
            ) : current === 'squats' ? (
              <Animated.View style={[styles.squatFigure, { transform: [{ translateY: squatTranslateY }] }]}>
                <View style={[styles.head, { backgroundColor: colors.text }]} />
                <View style={[styles.body, { backgroundColor: colors.text, height: 38 }]} />
                <View style={[styles.legLeft, { backgroundColor: colors.text, transform: [{ rotate: '0deg' }], height: 34 }]} />
                <View style={[styles.legRight, { backgroundColor: colors.text, transform: [{ rotate: '0deg' }], height: 34 }]} />
              </Animated.View>
            ) : current === 'high-knees' ? (
              <View style={styles.figureWide}>
                <Animated.View style={[styles.kneeLeg, { backgroundColor: colors.text, transform: [{ translateY: kneeLeft }] }]} />
                <Animated.View style={[styles.kneeLeg, { backgroundColor: colors.text, transform: [{ translateY: kneeRight }] }]} />
              </View>
            ) : current === 'lunges' ? (
              <View style={styles.figureWide}>
                <Animated.View style={[styles.lungeLeg, { backgroundColor: colors.text, transform: [{ translateY: lungeLeft }] }]} />
                <Animated.View style={[styles.lungeLeg, { backgroundColor: colors.text, transform: [{ translateY: lungeRight }] }]} />
              </View>
            ) : current === 'sit-ups' ? (
              <View style={styles.figure}>
                <View style={[styles.head, { backgroundColor: colors.text }]} />
                <View style={[styles.body, { backgroundColor: colors.text, width: 20, height: 28 }]} />
                <View style={[styles.legLeft, { backgroundColor: colors.text, transform: [{ rotate: '-30deg' }], height: 30 }]} />
                <View style={[styles.legRight, { backgroundColor: colors.text, transform: [{ rotate: '30deg' }], height: 30 }]} />
              </View>
            ) : (
              <View style={styles.plankFigure}>
                <View style={[styles.pushupBody, { backgroundColor: colors.text, width: 110 }]} />
              </View>
            )}
          </View>

          <View style={{ marginTop: 10 }}>
            {isAvoid ? (
              <Text style={{ fontSize: 13, color: colors.danger, fontWeight: '700' }}>
                This exercise is not recommended for your age/conditions.
              </Text>
            ) : isCaution ? (
              <Text style={{ fontSize: 13, color: colors.accent, fontWeight: '700' }}>
                Proceed with care. Modify form and intensity.
              </Text>
            ) : (
              <Text style={{ fontSize: 13, color: colors.muted }}>Good match for your profile.</Text>
            )}
            {rec.notes.length ? (
              <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>{rec.notes.join(' ')}</Text>
            ) : null}
          </View>

          <View style={{ marginTop: 12 }}>
            <Text style={{ fontSize: 16, fontWeight: '700', color: colors.accent }}>{headerRight}</Text>
          </View>

          <View style={[{ width: '100%', flexDirection: 'row', gap: 12, marginTop: 6 }]}>
            <Button text={running ? 'Stop' : 'Start'} onPress={running ? stop : start} style={{ flex: 1 }} disabled={isAvoid} />
            <Button
              text="Reset"
              onPress={() => {
                setReps(0);
                setDurationMs(0);
              }}
              variant="outline"
              style={{ flex: 1 }}
            />
          </View>
        </View>

        <View style={[{ width: '100%', flexDirection: 'row', gap: 12 }]}>
          <View style={[styles.infoCard(colors)]}>
            <Icon name="flame-outline" size={20} color={colors.highlight} />
            <Text style={{ color: colors.text, fontWeight: '600' }}>{calTip}</Text>
          </View>
          <View style={[styles.infoCard(colors)]}>
            <Icon name="timer-outline" size={20} color={colors.accent} />
            <Text style={{ color: colors.text, fontWeight: '600' }}>{tipSets}</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  stageCard: (colors: any) => ({
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    borderColor: colors.border,
    borderWidth: 1,
    boxShadow: '0px 10px 20px rgba(16, 18, 19, 0.06)',
    marginBottom: 12,
  }),
  stageTitle: (colors: any) => ({
    fontSize: 16,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 6,
  }),
  animStage: (colors: any) => ({
    height: 160,
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    marginTop: 6,
    alignItems: 'center',
    justifyContent: 'center',
  }),
  figure: {
    width: 120,
    height: 120,
    alignItems: 'center',
  },
  figureWide: {
    width: 160,
    height: 100,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 20,
  },
  head: {
    width: 18,
    height: 18,
    borderRadius: 9,
    marginBottom: 4,
  },
  body: {
    width: 6,
    height: 36,
    marginTop: 6,
    borderRadius: 3,
  },
  arm: {
    position: 'absolute',
    top: 22,
    width: 50,
    height: 4,
    borderRadius: 2,
  },
  legLeft: {
    position: 'absolute',
    bottom: 18,
    left: 40,
    width: 4,
    height: 40,
    transform: [{ rotate: '-10deg' }],
    borderRadius: 2,
  },
  legRight: {
    position: 'absolute',
    bottom: 18,
    right: 40,
    width: 4,
    height: 40,
    transform: [{ rotate: '10deg' }],
    borderRadius: 2,
  },
  pushupFigure: {
    width: 120,
    height: 60,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pushupBody: {
    width: 90,
    height: 8,
    borderRadius: 4,
  },
  pushupArm: {
    width: 30,
    height: 8,
    borderRadius: 4,
    transform: [{ rotate: '15deg' }],
    marginBottom: 6,
  },
  pushupLegs: {
    width: 60,
    height: 8,
    borderRadius: 4,
    marginTop: 6,
  },
  squatFigure: {
    width: 120,
    height: 100,
    alignItems: 'center',
    justifyContent: 'center',
  },
  kneeLeg: {
    width: 10,
    height: 40,
    borderRadius: 5,
    marginHorizontal: 8,
  },
  lungeLeg: {
    width: 12,
    height: 50,
    borderRadius: 6,
    marginHorizontal: 10,
  },
  plankFigure: {
    width: 140,
    height: 60,
    alignItems: 'center',
    justifyContent: 'center',
  },
  infoCard: (colors: any) => ({
    flex: 1,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: colors.card,
    borderRadius: 16,
    paddingHorizontal: 12,
    borderColor: colors.border,
    borderWidth: 1,
    boxShadow: '0px 10px 20px rgba(16, 18, 19, 0.06)',
  }),
  chip: (colors: any) => ({
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 18,
    backgroundColor: colors.backgroundAlt,
    borderWidth: 1,
  }),
  chipText: (colors: any) => ({
    fontSize: 12,
    color: colors.text,
    fontWeight: '700',
  }),
});
