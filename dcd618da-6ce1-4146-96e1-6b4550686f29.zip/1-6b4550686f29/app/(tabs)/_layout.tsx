
import { Tabs, Redirect } from 'expo-router';
import Icon from '../../components/Icon';
import { View, Pressable, useWindowDimensions } from 'react-native';
import SettingsSheet, { SettingsSheetRef } from '../../components/SettingsSheet';
import { useRef } from 'react';
import { useTheme } from '../../styles/commonStyles';
import { useUserProfile } from '../../hooks/useUserProfile';

export default function TabsLayout() {
  const sheetRef = useRef<SettingsSheetRef>(null);
  const { colors } = useTheme();
  const { width } = useWindowDimensions();
  const { profile, loading } = useUserProfile();

  // Guard: if no profile, redirect to login to avoid showing tabs when logged out
  if (!loading && !profile) {
    console.log('No profile detected in TabsLayout, redirecting to /login');
    return <Redirect href="/login" />;
  }

  // Responsive scale for floating settings button
  const baseWidth = 375;
  const scale = Math.max(0.85, Math.min(1.4, width / baseWidth));
  const pad = Math.max(8, Math.round(10 * scale));
  const radius = Math.max(18, Math.round(20 * scale));
  const iconSize = Math.max(18, Math.round(22 * scale));
  const offset = Math.max(10, Math.round(10 * scale));

  return (
    <View style={{ flex: 1 }}>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: colors.accent,
          tabBarInactiveTintColor: colors.text,
          tabBarStyle: {
            backgroundColor: colors.card,
            borderTopColor: colors.border,
            borderTopWidth: 1,
          },
        }}
      >
        <Tabs.Screen
          name="index"
          options={{
            title: 'Summary',
            tabBarIcon: ({ color, size }) => <Icon name="time-outline" color={color as string} size={size} />,
          }}
        />
        <Tabs.Screen
          name="exercises"
          options={{
            title: 'Exercises',
            tabBarIcon: ({ color, size }) => <Icon name="barbell-outline" color={color as string} size={size} />,
          }}
        />
        <Tabs.Screen
          name="motion"
          options={{
            title: 'Track',
            tabBarIcon: ({ color, size }) => <Icon name="walk-outline" color={color as string} size={size} />,
          }}
        />
        <Tabs.Screen
          name="profile"
          options={{
            title: 'Awards',
            tabBarIcon: ({ color, size }) => <Icon name="medal-outline" color={color as string} size={size} />,
          }}
        />
      </Tabs>

      <Pressable
        onPress={() => sheetRef.current?.open()}
        hitSlop={{ top: 8 * scale, bottom: 8 * scale, left: 8 * scale, right: 8 * scale }}
        style={{ position: 'absolute', right: 18, top: 10, display: 'contents' }}
        accessibilityRole="button"
        accessibilityLabel="Open settings"
      >
        <View
          style={{
            position: 'absolute',
            right: offset,
            top: offset,
            backgroundColor: colors.card,
            borderRadius: radius,
            padding: pad,
            borderColor: colors.border,
            borderWidth: 1,
            boxShadow: '0px 6px 14px rgba(0,0,0,0.15)',
            zIndex: 10,
          }}
        >
          <Icon name="settings-outline" size={iconSize} />
        </View>
      </Pressable>

      <SettingsSheet ref={sheetRef} />
    </View>
  );
}
