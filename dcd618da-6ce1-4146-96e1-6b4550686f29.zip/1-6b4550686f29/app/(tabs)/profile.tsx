
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, Platform } from 'react-native';
import { useTheme } from '../../styles/commonStyles';
import Svg, { Circle } from 'react-native-svg';
import { LinearGradient } from 'expo-linear-gradient';
import DoughnutChart from '../../components/DoughnutChart';
import Button from '../../components/Button';
import BottomSheet, { BottomSheetScrollView } from '@gorhom/bottom-sheet';
import { usePedometer } from '../../hooks/usePedometer';
import { getTodayKey, loadDailyStats } from '../../utils/activityStorage';

function AwardRings({ size = 220 }: { size?: number }) {
  const { colors } = useTheme();
  const cx = size / 2;
  const cy = size / 2;

  const rings = [
    { r: size * 0.34, stroke: '#7D7D80' },
    { r: size * 0.46, stroke: '#8A8A8E' },
    { r: size * 0.58, stroke: '#9D9DA2' },
  ];

  return (
    <Svg width={size} height={size}>
      {rings.map((ring, idx) => (
        <Circle
          key={idx}
          cx={cx}
          cy={cy}
          r={ring.r}
          stroke={ring.stroke}
          strokeWidth={size * 0.08}
          fill="none"
          opacity={0.95 - idx * 0.15}
        />
      ))}
      <Circle cx={cx} cy={cy} r={size * 0.1} fill={colors.card} />
    </Svg>
  );
}

function formatDateLabel(d: Date) {
  return `${d.getMonth() + 1}/${d.getDate()}`;
}

export default function ProfileScreen() {
  const { commonStyles, colors } = useTheme();
  const pedo = usePedometer(true);

  const [sheetMetric, setSheetMetric] = useState<'steps' | 'distance' | null>(null);
  const bottomRef = useRef<BottomSheet>(null);
  const snapPoints = useMemo(() => ['45%', '85%'], []);

  const stepsGoal = 8000;
  const distanceGoalMi = 5;

  const openSheet = (m: 'steps' | 'distance') => {
    setSheetMetric(m);
    requestAnimationFrame(() => bottomRef.current?.expand());
  };

  const [history, setHistory] = useState<{ date: string; steps: number }[]>([]);
  useEffect(() => {
    const load = async () => {
      const arr: { date: string; steps: number }[] = [];
      for (let i = 0; i < 7; i++) {
        const d = new Date(Date.now() - i * 24 * 60 * 60 * 1000);
        const key = getTodayKey(d);
        const stats = await loadDailyStats(key);
        arr.push({ date: formatDateLabel(d), steps: stats.steps || 0 });
      }
      setHistory(arr.reverse());
    };
    load();
  }, [pedo.totalSteps]);

  const distanceTodayMi = useMemo(() => pedo.distanceMiles, [pedo.distanceMiles]);
  const calories = useMemo(() => pedo.caloriesKcal, [pedo.caloriesKcal]);

  return (
    <View style={commonStyles.container}>
      <ScrollView contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 12, paddingBottom: 24 }}>
        <Text style={[commonStyles.h1, { marginBottom: 10 }]}>Awards</Text>

        <LinearGradient
          colors={[colors.card, colors.backgroundAlt]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.awardHero(colors)}
        >
          <Text style={styles.heroTitle(colors)}>Close Your Rings</Text>
          <View style={{ alignItems: 'center', marginTop: 8 }}>
            <AwardRings size={220} />
          </View>
          <Text style={styles.heroSubtitle(colors)}>New Move Goal</Text>
          <Text style={styles.heroMuted(colors)}>{Platform.OS === 'web' ? 'Use the native app for sensors' : 'Today'}</Text>

          <View style={{ flexDirection: 'row', gap: 10, marginTop: 12 }}>
            <Button text="Step Distance" onPress={() => openSheet('distance')} />
            <Button text="Step Count" variant="outline" onPress={() => openSheet('steps')} />
          </View>

          <View style={styles.heroFooter(colors)}>
            <View style={styles.heroBadge(colors)} />
            <View style={styles.heroBadge(colors)} />
            <View style={styles.heroBadge(colors)} />
            <View style={styles.heroBadge(colors)} />
            <View style={styles.heroBadge(colors)} />
            <View style={{ flex: 1 }} />
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={styles.moreText(colors)}>+10 more</Text>
              <Text style={styles.showAll(colors)}>Show All</Text>
            </View>
          </View>
        </LinearGradient>

        <View style={styles.gridRow}>
          <View style={styles.gridCard(colors)}>
            <Text style={styles.gridTitle(colors)}>Today's Steps</Text>
            <DoughnutChart
              progress={Math.min(1, pedo.totalSteps / stepsGoal)}
              color={colors.accent}
              label="Steps"
              valueText={`${pedo.totalSteps}/${stepsGoal}`}
              subText="Goal"
              size={120}
              thickness={14}
            />
          </View>

          <View style={styles.gridCard(colors)}>
            <Text style={styles.gridTitle(colors)}>Distance</Text>
            <DoughnutChart
              progress={Math.min(1, distanceTodayMi / distanceGoalMi)}
              color={colors.highlight}
              label="Miles"
              valueText={`${distanceTodayMi.toFixed(2)}/${distanceGoalMi}`}
              subText="Goal"
              size={120}
              thickness={14}
            />
          </View>
        </View>
      </ScrollView>

      <BottomSheet
        ref={bottomRef}
        index={-1}
        snapPoints={snapPoints}
        enablePanDownToClose
        backgroundStyle={{ backgroundColor: colors.card }}
        handleIndicatorStyle={{ backgroundColor: colors.border }}
      >
        <BottomSheetScrollView contentContainerStyle={{ padding: 16, paddingBottom: 30 }}>
          {sheetMetric === 'steps' ? (
            <View>
              <Text style={[styles.sheetTitle(colors)]}>Step Count</Text>
              <Text style={[styles.sheetSub(colors)]}>Today</Text>
              <View style={{ alignItems: 'center', marginTop: 6 }}>
                <DoughnutChart
                  progress={Math.min(1, pedo.totalSteps / stepsGoal)}
                  color={colors.accent}
                  label="Steps"
                  valueText={`${pedo.totalSteps}`}
                  subText={`Goal ${stepsGoal}`}
                  size={160}
                  thickness={16}
                />
              </View>

              <View style={[styles.statRow(colors)]}>
                <Text style={styles.statLabel(colors)}>Estimated calories</Text>
                <Text style={styles.statValue(colors)}>{calories.toFixed(0)} kcal</Text>
              </View>

              <View style={styles.divider(colors)} />
              <Text style={[styles.sectionTitle(colors)]}>Last 7 days</Text>
              <View style={{ marginTop: 8 }}>
                {history.map((h, i) => (
                  <View key={i} style={[styles.histRow(colors)]}>
                    <Text style={[styles.histDate(colors)]}>{h.date}</Text>
                    <View style={{ flex: 1, height: 6, backgroundColor: colors.backgroundAlt, borderRadius: 4, marginHorizontal: 8 }}>
                      <View
                        style={{
                          width: `${Math.min(100, (h.steps / stepsGoal) * 100)}%`,
                          backgroundColor: colors.accent,
                          height: 6,
                          borderRadius: 4,
                        }}
                      />
                    </View>
                    <Text style={[styles.histValue(colors)]}>{h.steps}</Text>
                  </View>
                ))}
                <Text style={[styles.hint(colors)]}>History builds as you use the app.</Text>
              </View>

              <Text style={[styles.sectionTitle(colors)]}>Milestones</Text>
              <Text style={[styles.hint(colors)]}>• 10,000 steps in a day (goal) • 50,000 weekly steps</Text>
            </View>
          ) : sheetMetric === 'distance' ? (
            <View>
              <Text style={[styles.sheetTitle(colors)]}>Step Distance</Text>
              <Text style={[styles.sheetSub(colors)]}>Today</Text>
              <View style={{ alignItems: 'center', marginTop: 6 }}>
                <DoughnutChart
                  progress={Math.min(1, distanceTodayMi / distanceGoalMi)}
                  color={colors.highlight}
                  label="Miles"
                  valueText={`${distanceTodayMi.toFixed(2)}`}
                  subText={`Goal ${distanceGoalMi} mi`}
                  size={160}
                  thickness={16}
                />
              </View>

              <View style={[styles.statRow(colors)]}>
                <Text style={styles.statLabel(colors)}>Avg step length</Text>
                <Text style={styles.statValue(colors)}>0.74 m</Text>
              </View>

              <View style={styles.divider(colors)} />
              <Text style={[styles.sectionTitle(colors)]}>Last 7 days</Text>
              <View style={{ marginTop: 8 }}>
                {history.map((h, i) => {
                  const miles = (h.steps * 0.74) / 1609.34;
                  return (
                    <View key={i} style={[styles.histRow(colors)]}>
                      <Text style={[styles.histDate(colors)]}>{h.date}</Text>
                      <View style={{ flex: 1, height: 6, backgroundColor: colors.backgroundAlt, borderRadius: 4, marginHorizontal: 8 }}>
                        <View
                          style={{
                            width: `${Math.min(100, (miles / distanceGoalMi) * 100)}%`,
                            backgroundColor: colors.highlight,
                            height: 6,
                            borderRadius: 4,
                          }}
                        />
                      </View>
                      <Text style={[styles.histValue(colors)]}>{miles.toFixed(2)} mi</Text>
                    </View>
                  );
                })}
                <Text style={[styles.hint(colors)]}>Keep moving to unlock achievements!</Text>
              </View>
            </View>
          ) : (
            <View>
              <Text style={[styles.sheetTitle(colors)]}>Details</Text>
              <Text style={[styles.hint(colors)]}>Pick a metric to see your data.</Text>
            </View>
          )}
        </BottomSheetScrollView>
      </BottomSheet>
    </View>
  );
}

const styles = StyleSheet.create({
  awardHero: (colors: any) => ({
    backgroundColor: colors.card,
    borderRadius: 20,
    padding: 16,
    borderColor: colors.border,
    borderWidth: 1,
    boxShadow: '0px 10px 20px rgba(0,0,0,0.25)',
    marginBottom: 12,
  }),
  heroTitle: (colors: any) => ({
    fontSize: 18,
    color: colors.text,
    fontWeight: '700',
  }),
  heroSubtitle: (colors: any) => ({
    fontSize: 16,
    color: colors.text,
    fontWeight: '700',
    textAlign: 'center',
    marginTop: 8,
  }),
  heroMuted: (colors: any) => ({
    fontSize: 13,
    color: colors.muted,
    textAlign: 'center',
    marginTop: 2,
  }),
  heroFooter: (colors: any) => ({
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  }),
  heroBadge: (colors: any) => ({
    width: 34,
    height: 34,
    borderRadius: 8,
    marginRight: 6,
    backgroundColor: colors.backgroundAlt,
    borderColor: colors.border,
    borderWidth: 1,
  }),
  moreText: (colors: any) => ({
    color: colors.muted,
    fontSize: 12,
  }),
  showAll: (colors: any) => ({
    color: colors.highlight,
    fontSize: 12,
    fontWeight: '700',
  }),
  gridRow: {
    flexDirection: 'row',
    gap: 12,
  },
  gridCard: (colors: any) => ({
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    borderColor: colors.border,
    borderWidth: 1,
    boxShadow: '0px 10px 20px rgba(0,0,0,0.25)',
    alignItems: 'center',
  }),
  gridTitle: (colors: any) => ({
    fontSize: 14,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 6,
  }),
  sheetTitle: (colors: any) => ({
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  }),
  sheetSub: (colors: any) => ({
    fontSize: 12,
    color: colors.muted,
  }),
  statRow: (colors: any) => ({
    marginTop: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
  }),
  statLabel: (colors: any) => ({
    color: colors.muted,
  }),
  statValue: (colors: any) => ({
    color: colors.text,
    fontWeight: '700',
  }),
  divider: (colors: any) => ({
    height: 1,
    backgroundColor: colors.border,
    marginVertical: 12,
  }),
  sectionTitle: (colors: any) => ({
    color: colors.text,
    fontWeight: '700',
    marginBottom: 4,
  }),
  histRow: (colors: any) => ({
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  }),
  histDate: (colors: any) => ({
    width: 44,
    color: colors.muted,
    fontSize: 12,
  }),
  histValue: (colors: any) => ({
    color: colors.text,
    fontWeight: '700',
    fontSize: 12,
  }),
  hint: (colors: any) => ({
    color: colors.muted,
    fontSize: 12,
    marginTop: 6,
  }),
});
