
import React, { useEffect, useState } from 'react';
import { Redirect } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { View } from 'react-native';

const STORAGE_KEY = 'user_profile';

export default function Main() {
  const [ready, setReady] = useState(false);
  const [hasProfile, setHasProfile] = useState<boolean | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        setHasProfile(!!raw);
      } catch (e) {
        console.log('Failed to read profile', e);
        setHasProfile(false);
      } finally {
        setReady(true);
      }
    };
    load();
  }, []);

  if (!ready) {
    // Small placeholder to avoid flashing wrong route
    return <View style={{ flex: 1 }} />;
  }

  if (hasProfile) {
    return <Redirect href="/(tabs)" />;
  }
  return <Redirect href="/login" />;
}
