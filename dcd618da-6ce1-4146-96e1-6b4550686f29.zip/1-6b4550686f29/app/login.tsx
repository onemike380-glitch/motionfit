
import React, { useEffect, useMemo, useState } from 'react';
import { ScrollView, View, Text, StyleSheet, TextInput, KeyboardAvoidingView, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import Button from '../components/Button';
import { useTheme } from '../styles/commonStyles';
import { useUserProfile, UserProfile } from '../hooks/useUserProfile';

export default function LoginScreen() {
  const { colors, commonStyles } = useTheme();
  const router = useRouter();
  const { profile, loading, saveProfile } = useUserProfile();

  const [name, setName] = useState('');
  const [age, setAge] = useState<string>('');
  const [height, setHeight] = useState<string>('');
  const [weight, setWeight] = useState<string>('');
  const [conditions, setConditions] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Redirect logged-in users without conditionally returning before hooks
  useEffect(() => {
    if (!loading && profile) {
      router.replace('/(tabs)');
    }
  }, [loading, profile, router]);

  const parsedProfile: UserProfile = useMemo(
    () => ({
      name: name.trim(),
      age: age ? Number(age) : null,
      heightCm: height ? Number(height) : null,
      weightKg: weight ? Number(weight) : null,
      conditions: conditions.trim() ? conditions.trim() : null,
    }),
    [name, age, height, weight, conditions]
  );

  const handleContinue = async () => {
    setError(null);
    if (parsedProfile.name.length < 2) {
      setError('Please enter your full name.');
      return;
    }
    try {
      await saveProfile(parsedProfile);
      router.replace('/(tabs)');
    } catch (e) {
      console.log('Error saving profile', e);
      setError('Something went wrong. Please try again.');
    }
  };

  return (
    <View style={commonStyles.container}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView
          contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 16, paddingBottom: 24 }}
          keyboardShouldPersistTaps="handled"
        >
          <Text style={[commonStyles.h1, { marginBottom: 6 }]}>Welcome</Text>
          <Text style={[commonStyles.subText, { marginBottom: 16, color: colors.muted }]}>
            Tell us a bit about you to personalize your experience.
          </Text>

          <View style={styles.card(colors)}>
            <Text style={styles.label(colors)}>Full name</Text>
            <TextInput
              value={name}
              onChangeText={setName}
              placeholder="e.g., Alex Johnson"
              placeholderTextColor={colors.muted}
              style={styles.input(colors)}
              autoCapitalize="words"
              returnKeyType="next"
            />

            <View style={styles.row}>
              <View style={{ flex: 1 }}>
                <Text style={styles.label(colors)}>Age</Text>
                <TextInput
                  value={age}
                  onChangeText={(t) => setAge(t.replace(/[^0-9]/g, ''))}
                  placeholder="e.g., 28"
                  placeholderTextColor={colors.muted}
                  style={styles.input(colors)}
                  keyboardType="number-pad"
                  returnKeyType="next"
                />
              </View>
              <View style={{ width: 12 }} />
              <View style={{ flex: 1 }}>
                <Text style={styles.label(colors)}>Height (cm)</Text>
                <TextInput
                  value={height}
                  onChangeText={(t) => setHeight(t.replace(/[^0-9]/g, ''))}
                  placeholder="e.g., 175"
                  placeholderTextColor={colors.muted}
                  style={styles.input(colors)}
                  keyboardType="number-pad"
                  returnKeyType="next"
                />
              </View>
            </View>

            <Text style={styles.label(colors)}>Weight (kg)</Text>
            <TextInput
              value={weight}
              onChangeText={(t) => setWeight(t.replace(/[^0-9.]/g, ''))}
              placeholder="e.g., 70"
              placeholderTextColor={colors.muted}
              style={styles.input(colors)}
              keyboardType="decimal-pad"
              returnKeyType="next"
            />

            <Text style={styles.label(colors)}>Health conditions (optional)</Text>
            <TextInput
              value={conditions}
              onChangeText={setConditions}
              placeholder="e.g., asthma, knee pain"
              placeholderTextColor={colors.muted}
              style={[styles.input(colors), { height: 80, textAlignVertical: 'top' }]}
              multiline
            />

            {error ? <Text style={[commonStyles.subText, { color: colors.danger }]}>{error}</Text> : null}

            <Button text="Continue" onPress={handleContinue} />
          </View>

          <View style={{ height: 8 }} />

          <View style={styles.cardMuted(colors)}>
            <Text style={[commonStyles.subText, { color: colors.muted }]}>
              Your info is stored only on this device. You can change it later in settings.
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  card: (colors: any) => ({
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    borderColor: colors.border,
    borderWidth: 1,
    boxShadow: '0px 10px 20px rgba(16, 18, 19, 0.06)',
  }),
  cardMuted: (colors: any) => ({
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    padding: 12,
    borderColor: colors.border,
    borderWidth: 1,
    boxShadow: '0px 6px 14px rgba(16, 18, 19, 0.06)',
  }),
  label: (colors: any) => ({
    color: colors.text,
    fontSize: 14,
    fontWeight: '700',
    marginTop: 10,
    marginBottom: 6,
  }),
  input: (colors: any) => ({
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.background,
    color: colors.text,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 12,
    fontSize: 16,
  }),
  row: {
    flexDirection: 'row',
    width: '100%',
    marginTop: 2,
  },
});
