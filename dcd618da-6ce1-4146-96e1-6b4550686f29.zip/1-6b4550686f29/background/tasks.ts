
import * as BackgroundFetch from 'expo-background-fetch';
import * as TaskManager from 'expo-task-manager';
import { Platform } from 'react-native';
import { Pedometer } from 'expo-sensors';
import { getTodayKey, updateStepsAndActiveEstimate } from '../utils/activityStorage';

export const TASK_NAME = 'activity-background-fetch';

if (Platform.OS !== 'web') {
  // Define the task once at module import time
  try {
    TaskManager.defineTask(TASK_NAME, async () => {
      try {
        const now = new Date();
        const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const res = await Pedometer.getStepCountAsync(startOfDay, now);
        const steps = res?.steps ?? 0;
        await updateStepsAndActiveEstimate(steps, Date.now(), getTodayKey(now));
        console.log('[BG] Updated steps via background fetch:', steps);
        return BackgroundFetch.BackgroundFetchResult.NewData;
      } catch (e) {
        console.log('[BG] Error in background task', e);
        return BackgroundFetch.BackgroundFetchResult.Failed;
      }
    });
  } catch (e) {
    console.log('TaskManager.defineTask error', e);
  }
}

export async function registerBackgroundFetchAsync() {
  if (Platform.OS === 'web') {
    console.log('BackgroundFetch not supported on web');
    return { ok: false, reason: 'web' as const };
  }
  try {
    const status = await BackgroundFetch.getStatusAsync();
    if (
      status === BackgroundFetch.BackgroundFetchStatus.Restricted ||
      status === BackgroundFetch.BackgroundFetchStatus.Denied
    ) {
      console.log('Background fetch not available');
      return { ok: false, reason: 'denied' as const };
    }
    const isRegistered = await TaskManager.isTaskRegisteredAsync(TASK_NAME);
    if (!isRegistered) {
      await BackgroundFetch.registerTaskAsync(TASK_NAME, {
        minimumInterval: 15 * 60, // every 15 minutes
        stopOnTerminate: false,
        startOnBoot: true,
      });
      console.log('Background fetch task registered');
    } else {
      console.log('Background fetch already registered');
    }
    return { ok: true as const };
  } catch (e) {
    console.log('Failed to register background fetch', e);
    return { ok: false, reason: 'error' as const };
  }
}
