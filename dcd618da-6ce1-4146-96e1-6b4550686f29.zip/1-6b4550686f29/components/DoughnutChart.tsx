
import React, { useEffect, useMemo, useRef } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { useTheme } from '../styles/commonStyles';

interface DoughnutChartProps {
  size?: number;
  thickness?: number;
  progress: number; // 0..1
  color?: string;
  trackColor?: string;
  label?: string;
  valueText?: string;
  subText?: string;
}

export default function DoughnutChart({
  size = 160,
  thickness = 16,
  progress,
  color,
  trackColor,
  label,
  valueText,
  subText,
}: DoughnutChartProps) {
  const { colors } = useTheme();

  const ringColor = color ?? colors.accent;
  const ringTrackColor = trackColor ?? (colors.border || '#E5E7EB');

  const radius = useMemo(() => (size - thickness) / 2, [size, thickness]);
  const circumference = useMemo(() => 2 * Math.PI * radius, [radius]);
  const animated = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(animated, {
      toValue: Math.min(1, Math.max(0, progress)),
      duration: 900,
      useNativeDriver: false,
    }).start();
  }, [progress, animated]);

  const strokeDashoffset = animated.interpolate({
    inputRange: [0, 1],
    outputRange: [circumference, 0],
  });

  return (
    <View style={{ width: size, height: size }}>
      <Svg width={size} height={size}>
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={ringTrackColor}
          strokeWidth={thickness}
          fill="none"
          strokeLinecap="round"
        />
        <AnimatedCircle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={ringColor}
          strokeWidth={thickness}
          fill="none"
          strokeDasharray={`${circumference}, ${circumference}`}
          strokeDashoffset={strokeDashoffset as unknown as number}
          strokeLinecap="round"
          rotation="-90"
          originX={size / 2}
          originY={size / 2}
        />
      </Svg>

      <View style={styles.centerContent}>
        {label ? <Text style={[styles.label, { color: colors.muted }]}>{label}</Text> : null}
        {valueText ? <Text style={[styles.valueText, { color: colors.text }]}>{valueText}</Text> : null}
        {subText ? <Text style={[styles.subText, { color: colors.muted }]}>{subText}</Text> : null}
      </View>
    </View>
  );
}

const AnimatedCircle = Animated.createAnimatedComponent(Circle);

const styles = StyleSheet.create({
  centerContent: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    pointerEvents: 'none',
  },
  label: {
    fontSize: 12,
    marginBottom: 2,
  },
  valueText: {
    fontSize: 20,
    fontWeight: '700',
  },
  subText: {
    fontSize: 12,
    marginTop: 2,
  },
});
