
import { Text, TouchableOpacity, StyleSheet, ViewStyle, TextStyle, useWindowDimensions } from 'react-native';
import { useTheme } from '../styles/commonStyles';
import * as Haptics from 'expo-haptics';

interface ButtonProps {
  text: string;
  onPress: () => void;
  style?: ViewStyle | ViewStyle[];
  textStyle?: TextStyle;
  variant?: 'primary' | 'secondary' | 'outline';
  disabled?: boolean;
}

export default function Button({ text, onPress, style, textStyle, variant = 'primary', disabled = false }: ButtonProps) {
  const { colors } = useTheme();
  const { width } = useWindowDimensions();

  // Responsive scaling based on screen width (375 reference)
  const baseWidth = 375;
  const scale = Math.max(0.85, Math.min(1.4, width / baseWidth));
  const paddingV = Math.max(10, Math.round(14 * scale));
  const paddingH = Math.max(12, Math.round(16 * scale));
  const radius = Math.max(10, Math.round(12 * scale));
  const minHeight = Math.max(44, Math.round(44 * scale * 0.9));
  const fontSize = Math.max(14, Math.min(20, Math.round(16 * scale)));

  const background =
    variant === 'outline'
      ? { backgroundColor: 'transparent', borderWidth: 1, borderColor: colors.primary }
      : variant === 'secondary'
      ? { backgroundColor: colors.secondary }
      : { backgroundColor: colors.primary };

  const textColor = variant === 'outline' ? colors.primary : '#fff';

  return (
    <TouchableOpacity
      style={[
        styles.button,
        {
          paddingVertical: paddingV,
          paddingHorizontal: paddingH,
          borderRadius: radius,
          minHeight,
          opacity: disabled ? 0.55 : 1,
        },
        background,
        style,
      ]}
      onPress={async () => {
        if (disabled) {
          console.log('Button disabled:', text);
          return;
        }
        try {
          await Haptics.selectionAsync();
        } catch (e) {
          console.log('Haptics selection error');
        }
        onPress();
      }}
      activeOpacity={0.75}
      hitSlop={{ top: 6 * scale, bottom: 6 * scale, left: 6 * scale, right: 6 * scale }}
      accessibilityRole="button"
      accessibilityLabel={text}
      accessibilityState={{ disabled }}
    >
      <Text style={[styles.buttonText, { color: textColor, fontSize }, textStyle]}>{text}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: 12,
    marginTop: 8,
    width: '100%',
    boxShadow: '0px 8px 18px rgba(0, 0, 0, 0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
});
