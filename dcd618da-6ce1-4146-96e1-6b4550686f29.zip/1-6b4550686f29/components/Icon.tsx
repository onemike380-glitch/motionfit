
import { View, StyleSheet, ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../styles/commonStyles';

interface IconProps {
  name: keyof typeof Ionicons.glyphMap;
  size?: number;
  style?: ViewStyle | ViewStyle[];
  color?: string;
}

export default function Icon({ name, size = 24, style, color }: IconProps) {
  const { colors } = useTheme();
  return (
    <View style={[styles.iconContainer, style]}>
      <Ionicons name={name} size={size} color={color ?? colors.text} />
    </View>
  );
}

const styles = StyleSheet.create({
  iconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
});
