
import React, { useMemo, useRef, useState, forwardRef, useImperativeHandle, useCallback } from 'react';
import BottomSheet, { BottomSheetView, BottomSheetScrollView } from '@gorhom/bottom-sheet';
import { View, Text, StyleSheet, Pressable, Switch, useWindowDimensions, Platform } from 'react-native';
import { useTheme } from '../styles/commonStyles';
import Button from './Button';
import { useNotifications } from '../hooks/useNotifications';
import * as Clipboard from 'expo-clipboard';
import { useRouter } from 'expo-router';
import { useUserProfile } from '../hooks/useUserProfile';
import { clearAllActivityData } from '../utils/activityStorage';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export type SettingsSheetRef = {
  open: () => void;
  close: () => void;
};

const SettingsSheet = forwardRef<SettingsSheetRef>((_, ref) => {
  const bottomSheetRef = useRef<BottomSheet>(null);
  const snapPoints = useMemo(() => ['35%', '80%'], []);
  const { colors, commonStyles, mode, toggleMode } = useTheme();
  const { width } = useWindowDimensions();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { clearProfile } = useUserProfile();

  const [dailyMoveGoal, setDailyMoveGoal] = useState(40);
  const [loggingOut, setLoggingOut] = useState(false);
  const [logoutError, setLogoutError] = useState<string | null>(null);

  // Notifications hook
  const {
    isSupported,
    permissionStatus,
    expoPushToken,
    requestPermission,
    scheduleLocal,
    sendPushToSelf,
    lastNotification,
  } = useNotifications();

  useImperativeHandle(ref, () => ({
    open: () => bottomSheetRef.current?.expand(),
    close: () => bottomSheetRef.current?.close(),
  }));

  const handleIncrease = useCallback(() => setDailyMoveGoal((g) => g + 10), []);
  const handleDecrease = useCallback(() => setDailyMoveGoal((g) => Math.max(10, g - 10)), []);

  const copyToken = useCallback(async () => {
    if (expoPushToken) {
      await Clipboard.setStringAsync(expoPushToken);
      console.log('Copied Expo push token to clipboard');
    } else {
      console.log('No token to copy');
    }
  }, [expoPushToken]);

  const handleLogout = useCallback(async () => {
    setLogoutError(null);
    setLoggingOut(true);
    try {
      console.log('Logging out: clearing profile and data, then navigating to login');
      await clearProfile();
      await clearAllActivityData();
      bottomSheetRef.current?.close();
      router.replace('/login');
    } catch (e) {
      console.log('Failed to logout', e);
      setLogoutError('Failed to log out. Please try again.');
    } finally {
      setLoggingOut(false);
    }
  }, [clearProfile, router]);

  // Responsive scale for touch areas and text link
  const baseWidth = 375;
  const scale = Math.max(0.85, Math.min(1.4, width / baseWidth));
  const closePadV = Math.max(8, Math.round(10 * scale));
  const closePadH = Math.max(12, Math.round(14 * scale));
  const closeFontSize = Math.max(14, Math.round(14 * scale));
  const bottomPad = Math.max(24, 24 + insets.bottom);

  return (
    <BottomSheet
      ref={bottomSheetRef}
      index={-1}
      snapPoints={snapPoints}
      enablePanDownToClose
      backgroundStyle={[styles.sheetBackground, { backgroundColor: colors.card }]}
      handleIndicatorStyle={[styles.indicator, { backgroundColor: colors.border }]}
    >
      <BottomSheetScrollView
        contentContainerStyle={[styles.content, { paddingBottom: bottomPad }]}
        showsVerticalScrollIndicator={false}
      >
        <Text style={[styles.title, { color: colors.text }]}>Quick Settings</Text>

        <View style={[commonStyles.card, { padding: 12 }]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Appearance</Text>
          <View style={[commonStyles.row, { alignItems: 'center', justifyContent: 'space-between' }]}>
            <Text style={{ color: colors.text, fontWeight: '600' }}>Dark Mode</Text>
            <Switch
              value={mode === 'dark'}
              onValueChange={toggleMode}
              trackColor={{ false: colors.border, true: colors.highlight }}
              thumbColor={mode === 'dark' ? '#ffffff' : '#ffffff'}
            />
          </View>
        </View>

        <View style={[commonStyles.card, { padding: 12 }]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Notifications</Text>

          {!isSupported ? (
            <Text style={{ color: colors.muted }}>
              Push notifications are not supported on web in Natively. Test this on iOS or Android.
            </Text>
          ) : (
            <>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <Text style={{ color: colors.text, fontWeight: '600' }}>Status</Text>
                <Text style={{ color: colors.muted, fontWeight: '600' }}>
                  {permissionStatus === 'granted'
                    ? 'Enabled'
                    : permissionStatus === 'denied'
                    ? 'Denied'
                    : permissionStatus === 'unavailable'
                    ? 'Unavailable'
                    : 'Ask'}
                </Text>
              </View>

              {permissionStatus !== 'granted' ? (
                <Button text="Enable Notifications" onPress={() => requestPermission()} />
              ) : (
                <>
                  <View style={[styles.tokenRow]}>
                    <Text style={[styles.tokenLabel, { color: colors.muted }]}>Expo Push Token</Text>
                    <Text
                      style={[styles.tokenValue, { color: colors.text }]}
                      numberOfLines={1}
                      ellipsizeMode="middle"
                    >
                      {expoPushToken || 'Loading...'}
                    </Text>
                    <Button text="Copy" variant="outline" onPress={copyToken} style={{ marginTop: 8 }} />
                  </View>

                  <View style={{ flexDirection: 'row', gap: 10 }}>
                    <Button
                      text="Test Local (2s)"
                      onPress={() => scheduleLocal(2, 'Local Test', 'This is a local test notification')}
                      style={{ flex: 1 }}
                    />
                    <Button
                      text="Send Push to Me"
                      variant="secondary"
                      onPress={() => sendPushToSelf('Hello from server', 'Sent through Expo push API')}
                      style={{ flex: 1 }}
                    />
                  </View>

                  {lastNotification ? (
                    <View style={{ marginTop: 8 }}>
                      <Text style={{ color: colors.muted, fontSize: 12, marginBottom: 4 }}>Last notification</Text>
                      <View style={[styles.lastCard(colors)]}>
                        <Text style={[styles.lastTitle(colors)]}>{lastNotification.title || 'No title'}</Text>
                        <Text style={{ color: colors.text }}>{lastNotification.body || 'No body'}</Text>
                        <Text style={{ color: colors.muted, fontSize: 11, marginTop: 4 }}>
                          {lastNotification.timestamp}
                        </Text>
                      </View>
                    </View>
                  ) : null}

                  {Platform.OS === 'ios' ? (
                    <Text style={{ color: colors.muted, fontSize: 12, marginTop: 6 }}>
                      Tip: On iOS, background/remote push tests require a development build or production app.
                    </Text>
                  ) : null}
                </>
              )}
            </>
          )}
        </View>

        <View style={[commonStyles.card, { padding: 12 }]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Daily Move Goal</Text>
          <Text style={[styles.goalText, { color: colors.accent }]}>{dailyMoveGoal} calories</Text>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Button text="- 10" onPress={handleDecrease} variant="outline" style={{ flex: 1 }} />
            <Button text="+ 10" onPress={handleIncrease} style={{ flex: 1 }} />
          </View>
        </View>

        <View style={[commonStyles.card, { padding: 12 }]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>About</Text>
          <Text style={[styles.aboutText, { color: colors.muted }]}>
            Minimal, elegant workout tracker with animated exercises and motion tracking. Now with push notifications.
          </Text>
        </View>

        <View style={[commonStyles.card, { padding: 12 }]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Account</Text>
          <Text style={{ color: colors.muted, fontSize: 12, marginBottom: 8 }}>
            Logging out clears your profile and local activity data from this device.
          </Text>
          {logoutError ? (
            <Text style={{ color: colors.danger, marginBottom: 6, fontWeight: '600' }}>{logoutError}</Text>
          ) : null}
          <Button
            text={loggingOut ? 'Logging out…' : 'Log out'}
            variant="outline"
            onPress={handleLogout}
            disabled={loggingOut}
            style={{ borderColor: colors.danger }}
            textStyle={{ color: colors.danger, fontWeight: '700' }}
          />
        </View>

        <Pressable
          style={[styles.close, { paddingVertical: closePadV, paddingHorizontal: closePadH }]}
          onPress={() => bottomSheetRef.current?.close()}
          hitSlop={{ top: 8 * scale, bottom: 8 * scale, left: 8 * scale, right: 8 * scale }}
          accessibilityRole="button"
          accessibilityLabel="Close settings"
        >
          <Text style={[styles.closeText, { color: colors.primary, fontSize: closeFontSize }]}>Close</Text>
        </Pressable>
      </BottomSheetScrollView>
    </BottomSheet>
  );
});

SettingsSheet.displayName = 'SettingsSheet';

const styles = StyleSheet.create({
  sheetBackground: {
    borderTopLeftRadius: 18,
    borderTopRightRadius: 18,
  },
  indicator: {},
  content: {
    flexGrow: 1,
    padding: 16,
    gap: 12,
  },
  title: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 6,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 6,
  },
  goalText: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 10,
  },
  aboutText: {
    fontSize: 14,
    marginBottom: 10,
  },
  close: {
    alignSelf: 'center',
    paddingVertical: 10,
    paddingHorizontal: 16,
  },
  closeText: {
    fontWeight: '700',
  },
  tokenRow: {
    marginTop: 6,
    marginBottom: 8,
  },
  tokenLabel: {
    fontSize: 12,
    marginBottom: 4,
  },
  tokenValue: {
    fontSize: 12,
    fontWeight: '700',
  },
  lastCard: (colors: any) => ({
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    padding: 10,
    borderColor: colors.border,
    borderWidth: 1,
    boxShadow: '0px 6px 14px rgba(0,0,0,0.10)',
  }),
  lastTitle: (colors: any) => ({
    fontSize: 14,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 2,
  }),
});

export default SettingsSheet;
