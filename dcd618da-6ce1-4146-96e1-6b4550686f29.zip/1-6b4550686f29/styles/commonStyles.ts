
import React, { createContext, useContext, useMemo, useState } from 'react';
import { StyleSheet } from 'react-native';

export type ThemeMode = 'light' | 'dark';

export type Colors = {
  background: string;
  backgroundAlt: string;
  text: string;
  primary: string;
  secondary: string;
  accent: string;
  highlight: string;
  muted: string;
  card: string;
  border: string;
  success?: string;
  danger?: string;
};

export const lightColors: Colors = {
  background: '#FFFFFF',
  backgroundAlt: '#F5F7FA',
  text: '#101213',
  primary: '#1E88E5',
  secondary: '#1565C0',
  accent: '#3B82F6',
  highlight: '#22C55E',
  muted: '#94A3B8',
  card: '#FFFFFF',
  border: '#E5E7EB',
  success: '#22C55E',
  danger: '#EF4444',
};

// Dark palette inspired by the provided Awards screenshot
export const darkColors: Colors = {
  background: '#0B0B0D',
  backgroundAlt: '#141416',
  text: '#F2F2F7',
  primary: '#0A84FF',
  secondary: '#64D2FF',
  accent: '#0A84FF',
  highlight: '#32D74B',
  muted: '#A1A1AA',
  card: '#1C1C1E',
  border: '#2C2C2E',
  success: '#32D74B',
  danger: '#FF453A',
};

function makeCommonStylesInternal(c: Colors) {
  return StyleSheet.create({
    wrapper: {
      backgroundColor: c.background,
      width: '100%',
      height: '100%',
    },
    container: {
      flex: 1,
      backgroundColor: c.background,
      width: '100%',
      height: '100%',
    },
    content: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      maxWidth: 900,
      width: '100%',
      paddingHorizontal: 20,
    },
    screenHeaderRow: {
      width: '100%',
      paddingHorizontal: 20,
      paddingTop: 8,
      paddingBottom: 4,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    h1: {
      fontSize: 28,
      fontWeight: '700',
      color: c.text,
    },
    h2: {
      fontSize: 20,
      fontWeight: '700',
      color: c.text,
    },
    text: {
      fontSize: 16,
      fontWeight: '400',
      color: c.text,
      lineHeight: 22,
    },
    subText: {
      fontSize: 13,
      color: c.muted,
    },
    section: {
      width: '100%',
      alignItems: 'center',
      paddingHorizontal: 20,
      marginTop: 10,
    },
    buttonContainer: {
      width: '100%',
      alignItems: 'center',
      paddingHorizontal: 20,
      marginTop: 12,
    },
    card: {
      backgroundColor: c.card,
      borderRadius: 16,
      padding: 16,
      marginVertical: 8,
      width: '100%',
      borderColor: c.border,
      borderWidth: 1,
      boxShadow: '0px 10px 20px rgba(16, 18, 19, 0.06)',
    },
    row: {
      width: '100%',
      flexDirection: 'row',
      gap: 12,
    },
    col: {
      flex: 1,
    },
    icon: {
      width: 60,
      height: 60,
    },
    divider: {
      height: 1,
      width: '100%',
      backgroundColor: c.border,
      marginVertical: 12,
    },
    chip: {
      paddingVertical: 6,
      paddingHorizontal: 10,
      borderRadius: 14,
      backgroundColor: c.backgroundAlt,
      alignSelf: 'flex-start',
    },
    chipText: {
      fontSize: 12,
      color: c.text,
    },
    floatingButton: {
      position: 'absolute',
      right: 20,
      top: 14,
      backgroundColor: c.card,
      borderRadius: 24,
      padding: 10,
      boxShadow: '0px 6px 14px rgba(0,0,0,0.15)',
      borderColor: c.border,
      borderWidth: 1,
      zIndex: 5,
    },
  });
}

export const ThemeContext = createContext<{
  mode: ThemeMode;
  colors: Colors;
  commonStyles: ReturnType<typeof makeCommonStylesInternal>;
  setMode: (m: ThemeMode) => void;
  toggleMode: () => void;
}>({
  mode: 'light',
  colors: lightColors,
  commonStyles: makeCommonStylesInternal(lightColors),
  setMode: () => {},
  toggleMode: () => {},
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = useState<ThemeMode>('light');

  const colors = useMemo(() => (mode === 'dark' ? darkColors : lightColors), [mode]);
  const styles = useMemo(() => makeCommonStylesInternal(colors), [colors]);

  const toggleMode = () => setMode((m) => (m === 'dark' ? 'light' : 'dark'));

  const value = useMemo(
    () => ({ mode, colors, commonStyles: styles, setMode, toggleMode }),
    [mode, colors, styles]
  );
  // Avoid JSX in .ts files to keep ESLint parser happy
  return React.createElement(ThemeContext.Provider, { value }, children as React.ReactNode);
}

export function useTheme() {
  return useContext(ThemeContext);
}

// Backward compatible named exports for any static usage
export const colors = lightColors;
export const commonStyles = makeCommonStylesInternal(lightColors);
