
import { useEffect, useState } from 'react';
import { Accelerometer, Gyroscope } from 'expo-sensors';

export type Vector3 = { x: number; y: number; z: number };

export function useMotion(enabled = true, intervalMs = 250) {
  const [accel, setAccel] = useState<Vector3>({ x: 0, y: 0, z: 0 });
  const [gyro, setGyro] = useState<Vector3>({ x: 0, y: 0, z: 0 });
  const [accelMag, setAccelMag] = useState(0);
  const [gyroMag, setGyroMag] = useState(0);

  useEffect(() => {
    let accelSub: any;
    let gyroSub: any;

    if (enabled) {
      try {
        Accelerometer.setUpdateInterval(intervalMs);
        accelSub = Accelerometer.addListener((data) => {
          setAccel(data);
          const mag = Math.sqrt(data.x * data.x + data.y * data.y + data.z * data.z);
          setAccelMag(mag);
        });
      } catch (e) {
        console.log('Accelerometer error', e);
      }

      try {
        Gyroscope.setUpdateInterval(intervalMs);
        gyroSub = Gyroscope.addListener((data) => {
          setGyro(data);
          const mag = Math.sqrt(data.x * data.x + data.y * data.y + data.z * data.z);
          setGyroMag(mag);
        });
      } catch (e) {
        console.log('Gyroscope error', e);
      }
    }

    return () => {
      try {
        accelSub && accelSub.remove?.();
      } catch (e) {
        console.log('Error removing accelerometer sub', e);
      }
      try {
        gyroSub && gyroSub.remove?.();
      } catch (e) {
        console.log('Error removing gyroscope sub', e);
      }
    };
  }, [enabled, intervalMs]);

  return { accel, gyro, accelMag, gyroMag };
}
