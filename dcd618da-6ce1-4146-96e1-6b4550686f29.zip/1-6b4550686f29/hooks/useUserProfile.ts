
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useCallback, useEffect, useState } from 'react';

export type UserProfile = {
  name: string;
  age?: number | null;
  heightCm?: number | null;
  weightKg?: number | null;
  conditions?: string | null;
};

const STORAGE_KEY = 'user_profile';

export async function getStoredProfile(): Promise<UserProfile | null> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed as UserProfile;
  } catch (e) {
    console.log('Failed to load user profile', e);
    return null;
  }
}

export async function saveStoredProfile(profile: UserProfile): Promise<void> {
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  } catch (e) {
    console.log('Failed to save user profile', e);
  }
}

export async function clearStoredProfile(): Promise<void> {
  try {
    await AsyncStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.log('Failed to clear user profile', e);
  }
}

export function useUserProfile() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    const p = await getStoredProfile();
    setProfile(p);
    setLoading(false);
  }, []);

  const saveProfile = useCallback(async (p: UserProfile) => {
    await saveStoredProfile(p);
    setProfile(p);
  }, []);

  const clearProfile = useCallback(async () => {
    await clearStoredProfile();
    setProfile(null);
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { profile, loading, saveProfile, clearProfile, refresh };
}
