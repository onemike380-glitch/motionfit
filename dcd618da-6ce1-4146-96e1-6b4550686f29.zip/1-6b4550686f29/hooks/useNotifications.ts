
import { useEffect, useMemo, useRef, useState } from 'react';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import { Platform } from 'react-native';

export type NotificationPermissionStatus = 'undetermined' | 'granted' | 'denied' | 'unavailable';

type LastNotification = {
  id?: string | null;
  title?: string | null;
  body?: string | null;
  data?: any;
  timestamp?: string;
} | null;

// Foreground behavior: show alerts, play sound, set badge
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

async function getProjectId(): Promise<string | undefined> {
  try {
    // Newer SDKs expose project id here when using EAS
    // Fallbacks attempt to read from expoConfig if available in dev
    const fromEas = (Constants as any)?.easConfig?.projectId;
    const fromExpoConfig = (Constants as any)?.expoConfig?.extra?.eas?.projectId;
    return fromEas || fromExpoConfig;
  } catch (e) {
    console.log('Unable to resolve projectId for push token', e);
    return undefined;
  }
}

export function useNotifications() {
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermissionStatus>('undetermined');
  const [expoPushToken, setExpoPushToken] = useState<string | null>(null);
  const [lastNotification, setLastNotification] = useState<LastNotification>(null);
  const [isSupported, setIsSupported] = useState(true);

  const receivedListener = useRef<Notifications.Subscription | null>(null);
  const responseListener = useRef<Notifications.Subscription | null>(null);

  useEffect(() => {
    // Web environment (Natively web preview) does not support push
    if (Platform.OS === 'web') {
      setIsSupported(false);
      setPermissionStatus('unavailable');
      return;
    }

    let isMounted = true;

    const init = async () => {
      try {
        const settings = await Notifications.getPermissionsAsync();
        if (!isMounted) return;

        setPermissionStatus(settings.granted ? 'granted' : settings.status === 'denied' ? 'denied' : 'undetermined');

        if (settings.granted) {
          await ensurePushToken();
        }
      } catch (e) {
        console.log('Notifications init error', e);
        if (isMounted) setPermissionStatus('unavailable');
      }
    };

    init();

    // Listeners: receive and response
    try {
      receivedListener.current = Notifications.addNotificationReceivedListener((n) => {
        const content = n.request?.content;
        setLastNotification({
          id: n.request?.identifier,
          title: content?.title,
          body: content?.body,
          data: content?.data,
          timestamp: new Date().toISOString(),
        });
      });

      responseListener.current = Notifications.addNotificationResponseReceivedListener((response) => {
        const n = response.notification;
        const content = n.request?.content;
        setLastNotification({
          id: n.request?.identifier,
          title: content?.title,
          body: content?.body,
          data: content?.data,
          timestamp: new Date().toISOString(),
        });
      });
    } catch (e) {
      console.log('Error wiring notification listeners', e);
    }

    return () => {
      isMounted = false;
      try {
        receivedListener.current?.remove();
      } catch (e) {
        console.log('Failed removing received listener', e);
      } finally {
        receivedListener.current = null;
      }
      try {
        responseListener.current?.remove();
      } catch (e) {
        console.log('Failed removing response listener', e);
      } finally {
        responseListener.current = null;
      }
    };
  }, []);

  const requestPermission = async () => {
    if (Platform.OS === 'web') {
      setIsSupported(false);
      setPermissionStatus('unavailable');
      return { granted: false };
    }
    try {
      const req = await Notifications.requestPermissionsAsync();
      const granted = !!req.granted;
      setPermissionStatus(granted ? 'granted' : 'denied');
      if (granted) {
        await ensurePushToken();
      }
      return req;
    } catch (e) {
      console.log('Request permission error', e);
      setPermissionStatus('unavailable');
      return { granted: false };
    }
  };

  const ensurePushToken = async () => {
    try {
      const projectId = await getProjectId();
      const tokenResponse = await Notifications.getExpoPushTokenAsync(projectId ? { projectId } : undefined);
      const token = tokenResponse?.data ?? null;
      console.log('Expo push token:', token);
      setExpoPushToken(token);
      return token;
    } catch (e) {
      console.log('Error getting Expo push token', e);
      setExpoPushToken(null);
      return null;
    }
  };

  // Schedule a local notification after X seconds
  const scheduleLocal = async (seconds = 2, title = 'Hello from Natively', body = 'This is a local test notification') => {
    if (!isSupported) {
      console.log('Local notifications not supported on this platform');
      return null;
    }
    try {
      const id = await Notifications.scheduleNotificationAsync({
        content: {
          title,
          body,
          sound: true,
        },
        trigger: { seconds, channelId: Platform.OS === 'android' ? 'default' : undefined },
      });
      console.log('Scheduled local notification', id);
      return id;
    } catch (e) {
      console.log('Failed to schedule local notification', e);
      return null;
    }
  };

  // Create default Android channel once
  useEffect(() => {
    if (Platform.OS === 'android') {
      Notifications.setNotificationChannelAsync('default', {
        name: 'Default',
        importance: Notifications.AndroidImportance.DEFAULT,
        sound: 'default',
        vibrationPattern: [200, 200, 200],
        lightColor: '#3B82F6',
      }).catch((e) => console.log('Channel error', e));
    }
  }, []);

  // Send a push to self via Expo Push API (for quick testing only)
  const sendPushToSelf = async (title = 'Push from device', body = 'This used the Expo push API') => {
    if (!expoPushToken) {
      console.log('No expoPushToken available yet');
      return { ok: false, message: 'No token' };
    }
    try {
      const res = await fetch('https://exp.host/--/api/v2/push/send', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Accept-encoding': 'gzip, deflate',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          to: expoPushToken,
          sound: 'default',
          title,
          body,
          data: { from: 'natively' },
        }),
      });
      const json = await res.json();
      console.log('Push API response', json);
      return { ok: true, json };
    } catch (e) {
      console.log('Failed to send push via Expo API', e);
      return { ok: false, message: 'network' };
    }
  };

  return {
    isSupported,
    permissionStatus,
    expoPushToken,
    lastNotification,
    requestPermission,
    ensurePushToken,
    scheduleLocal,
    sendPushToSelf,
  };
}
