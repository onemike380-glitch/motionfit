
import { useEffect, useMemo, useRef, useState } from 'react';
import { useMotion } from './useMotion';

// Simple auto-start/auto-pause live activity session based on motion.
// Starts from 0 when motion crosses threshold, pauses when still for quietWindowMs.
export function useLiveActivity(enabled = true, options?: { sampleMs?: number; threshold?: number; quietWindowMs?: number }) {
  const sampleMs = options?.sampleMs ?? 300;
  const threshold = options?.threshold ?? 0.12; // accel magnitude delta from gravity ~1g
  const quietWindowMs = options?.quietWindowMs ?? 5000;

  const { accelMag } = useMotion(enabled, sampleMs);
  const [active, setActive] = useState(false);
  const [elapsedMs, setElapsedMs] = useState(0);
  const lastMotionRef = useRef<number>(Date.now());
  const rafRef = useRef<NodeJS.Timeout | null>(null);

  const motionScore = Math.abs((accelMag || 0) - 1);

  // Detect motion vs idle
  useEffect(() => {
    if (!enabled) {
      setActive(false);
      return;
    }
    const now = Date.now();
    if (motionScore >= threshold) {
      lastMotionRef.current = now;
      // start session if not already active
      if (!active) {
        setElapsedMs(0);
        setActive(true);
      }
    } else {
      // if quiet for window, pause
      if (active && now - lastMotionRef.current > quietWindowMs) {
        setActive(false);
      }
    }
  }, [motionScore, enabled, active, threshold, quietWindowMs]);

  // Ticker to increment elapsed while active
  useEffect(() => {
    if (!enabled) {
      if (rafRef.current) clearInterval(rafRef.current);
      rafRef.current = null;
      return;
    }
    if (active) {
      if (!rafRef.current) {
        rafRef.current = setInterval(() => {
          setElapsedMs((ms) => ms + 1000);
        }, 1000);
      }
    } else {
      if (rafRef.current) {
        clearInterval(rafRef.current);
        rafRef.current = null;
      }
    }
    return () => {
      if (rafRef.current) {
        clearInterval(rafRef.current);
        rafRef.current = null;
      }
    };
  }, [active, enabled]);

  const reset = () => setElapsedMs(0);

  const elapsedSec = useMemo(() => Math.floor(elapsedMs / 1000), [elapsedMs]);

  return { active, elapsedMs, elapsedSec, reset };
}
