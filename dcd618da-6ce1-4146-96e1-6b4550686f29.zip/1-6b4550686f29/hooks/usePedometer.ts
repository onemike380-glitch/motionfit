
import { useEffect, useMemo, useRef, useState } from 'react';
import { Platform } from 'react-native';
import { Pedometer } from 'expo-sensors';

export type PedometerStatus = 'checking' | 'granted' | 'denied' | 'unavailable';

export function usePedometer(enabled = true) {
  const [isAvailable, setIsAvailable] = useState<boolean | null>(null);
  const [status, setStatus] = useState<PedometerStatus>('checking');

  const [todaySteps, setTodaySteps] = useState(0);
  const [sessionSteps, setSessionSteps] = useState(0);

  const watcherRef = useRef<ReturnType<typeof Pedometer.watchStepCount> | null>(null);

  // Distance estimation using average step length (meters). This varies by person; we use 0.74m by default.
  const stepLengthMeters = 0.74;

  // Rough calorie estimation (kcal). Very rough; depends on weight/speed. Using ~0.04 kcal/step.
  const kcalPerStep = 0.04;

  const distanceMeters = useMemo(() => {
    return (todaySteps + sessionSteps) * stepLengthMeters;
  }, [todaySteps, sessionSteps]);

  const distanceMiles = useMemo(() => distanceMeters / 1609.34, [distanceMeters]);
  const caloriesKcal = useMemo(() => {
    return (todaySteps + sessionSteps) * kcalPerStep;
  }, [todaySteps, sessionSteps]);

  // Reset session steps when enabled toggles on
  useEffect(() => {
    if (enabled) {
      setSessionSteps(0);
    } else {
      if (watcherRef.current) {
        watcherRef.current.remove();
        watcherRef.current = null;
      }
    }
  }, [enabled]);

  useEffect(() => {
    let isMounted = true;

    const init = async () => {
      try {
        const hardwareAvailable = await Pedometer.isAvailableAsync();
        if (!isMounted) return;
        setIsAvailable(hardwareAvailable);
        if (!hardwareAvailable) {
          setStatus('unavailable');
          console.log('Pedometer hardware not available');
          return;
        }

        // Web note
        if (Platform.OS === 'web') {
          // Motion sensors are usually not supported on web in this environment.
          setStatus('unavailable');
          console.log('Pedometer not available on web environment');
          return;
        }

        // Permissions (Android 10+, iOS Core Motion)
        const existing = await Pedometer.getPermissionsAsync();
        if (!isMounted) return;

        if (existing && existing.granted) {
          setStatus('granted');
        } else {
          const req = await Pedometer.requestPermissionsAsync();
          if (!isMounted) return;
          setStatus(req.granted ? 'granted' : 'denied');
        }

        if (enabled && (existing?.granted || (await Pedometer.getPermissionsAsync()).granted)) {
          // Count today steps
          const now = new Date();
          const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
          try {
            const res = await Pedometer.getStepCountAsync(startOfDay, now);
            if (!isMounted) return;
            setTodaySteps(res.steps ?? 0);
          } catch (e) {
            console.log('Error getting today step count', e);
          }

          // Start live watcher for session steps
          try {
            watcherRef.current = Pedometer.watchStepCount(({ steps }) => {
              setSessionSteps(steps);
            });
          } catch (e) {
            console.log('Error starting step watcher', e);
          }
        }
      } catch (e) {
        console.log('Pedometer init error', e);
        if (isMounted) setStatus('unavailable');
      }
    };

    if (enabled) init();

    return () => {
      isMounted = false;
      try {
        watcherRef.current?.remove();
      } catch (e) {
        console.log('Error removing step watcher', e);
      } finally {
        watcherRef.current = null;
      }
    };
  }, [enabled]);

  return {
    isAvailable,
    status,
    todaySteps,
    sessionSteps,
    totalSteps: todaySteps + sessionSteps,
    distanceMeters,
    distanceMiles,
    caloriesKcal,
  };
}
