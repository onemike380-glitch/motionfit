
import { Platform } from 'react-native';

export type Exercise =
  | 'jumping-jacks'
  | 'push-ups'
  | 'squats'
  | 'lunges'
  | 'sit-ups'
  | 'high-knees'
  | 'plank';

export const ALL_EXERCISES: Exercise[] = [
  'jumping-jacks',
  'push-ups',
  'squats',
  'lunges',
  'sit-ups',
  'high-knees',
  'plank',
];

export const exerciseLabels: Record<Exercise, string> = {
  'jumping-jacks': 'Jumping Jacks',
  'push-ups': 'Push Ups',
  squats: 'Squats',
  lunges: 'Lunges',
  'sit-ups': 'Sit Ups',
  'high-knees': 'High Knees',
  plank: 'Plank',
};

export type AgeCategory = 'child' | 'teen' | 'adult' | 'senior';

export function getAgeCategory(age?: number | null): AgeCategory {
  if (!age || age <= 0) return 'adult';
  if (age <= 12) return 'child';
  if (age <= 17) return 'teen';
  if (age <= 64) return 'adult';
  return 'senior';
}

export type Recommendation = {
  category: AgeCategory;
  recommended: Exercise[];
  caution: Exercise[];
  avoid: Exercise[];
  notes: string[];
};

// Basic intensity grouping to power the info card text
export function getIntensity(ex: Exercise): 'low' | 'moderate' | 'high' {
  switch (ex) {
    case 'plank':
    case 'lunges':
      return 'low';
    case 'squats':
    case 'sit-ups':
    case 'push-ups':
      return 'moderate';
    case 'high-knees':
    case 'jumping-jacks':
      return 'high';
  }
}

export function getExerciseRecommendations(
  age?: number | null,
  conditionsRaw?: string | null
): Recommendation {
  const category = getAgeCategory(age);
  const conditions = (conditionsRaw || '').toLowerCase();

  // Base age guidance
  let recommended: Exercise[] = [];
  let caution: Exercise[] = [];
  let avoid: Exercise[] = [];
  const notes: string[] = [];

  if (category === 'child') {
    recommended = ['jumping-jacks', 'high-knees', 'squats'];
    caution = ['lunges', 'push-ups', 'plank'];
    avoid = ['sit-ups'];
    notes.push('Children: focus on fun, bodyweight, and form. Avoid strain.');
  } else if (category === 'teen') {
    recommended = ['jumping-jacks', 'high-knees', 'squats', 'lunges', 'push-ups', 'plank', 'sit-ups'];
    caution = [];
    avoid = [];
    notes.push('Teens: all bodyweight moves are generally fine with proper form.');
  } else if (category === 'adult') {
    recommended = ['jumping-jacks', 'high-knees', 'squats', 'lunges', 'push-ups', 'plank', 'sit-ups'];
    caution = [];
    avoid = [];
    notes.push('Adults: choose a balanced mix and listen to your body.');
  } else {
    // senior
    recommended = ['squats', 'lunges', 'plank', 'high-knees'];
    caution = ['push-ups'];
    avoid = ['jumping-jacks', 'sit-ups'];
    notes.push('Seniors: prioritize low-impact moves and stability. Modify as needed.');
  }

  // Conditions adjustments
  if (conditions) {
    if (conditions.includes('knee')) {
      // Knee-sensitive: reduce impact and knee-heavy flexion
      // jumping-jacks worst, high-knees/ lunges/ squats can be caution depending on form
      avoid = uniq([...avoid, 'jumping-jacks']);
      caution = uniq([...caution, 'high-knees', 'lunges', 'squats']);
      notes.push('Knee note: Limit impact; prefer controlled, low-depth squats and supported lunges.');
    }
    if (conditions.includes('back')) {
      // Back-sensitive: be careful with sit-ups and long planks
      avoid = uniq([...avoid, 'sit-ups']);
      caution = uniq([...caution, 'plank', 'lunges']);
      notes.push('Back note: Prefer neutral-spine core work. Avoid sit-ups.');
    }
    if (conditions.includes('shoulder')) {
      // Shoulder-sensitive: push-ups can aggravate
      caution = uniq([...caution, 'push-ups', 'plank']);
      notes.push('Shoulder note: Reduce load on shoulders; modify push-ups on knees or wall.');
    }
  }

  // Make sure arrays are consistent and mutually exclusive
  avoid = uniq(avoid);
  caution = uniq(caution.filter((e) => !avoid.includes(e)));
  recommended = uniq(recommended.filter((e) => !avoid.includes(e)));

  return { category, recommended, caution, avoid, notes };
}

function uniq<T>(arr: T[]): T[] {
  return Array.from(new Set(arr));
}
