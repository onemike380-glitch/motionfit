
import AsyncStorage from '@react-native-async-storage/async-storage';

export type DailyStats = {
  steps: number;
  activeMs: number; // active time today in milliseconds (approx)
  lastSteps: number;
  lastFetchTs: number; // unix ms
  // Wellness trackers
  waterMl?: number; // water intake in milliliters for the day
  sleepMin?: number; // sleep duration in minutes (user-logged)
  calorieIntakeKcal?: number; // food calories intake in kcal
};

export type ExerciseLogItem = {
  id: string;
  type: string;
  reps?: number | null;
  durationMs?: number | null;
  timestamp: number; // unix ms
};

const DAILY_PREFIX = 'daily_stats_';
const EXERCISE_LOGS_KEY = 'exercise_logs';

function pad(n: number) {
  return n < 10 ? `0${n}` : `${n}`;
}

export function getTodayKey(date = new Date()) {
  const y = date.getFullYear();
  const m = pad(date.getMonth() + 1);
  const d = pad(date.getDate());
  return `${y}-${m}-${d}`;
}

export async function loadDailyStats(dateKey: string): Promise<DailyStats> {
  try {
    const raw = await AsyncStorage.getItem(DAILY_PREFIX + dateKey);
    if (!raw) {
      return { steps: 0, activeMs: 0, lastSteps: 0, lastFetchTs: Date.now(), waterMl: 0, sleepMin: 0, calorieIntakeKcal: 0 };
    }
    const parsed = JSON.parse(raw) as DailyStats;
    // ensure fields
    return {
      steps: parsed.steps ?? 0,
      activeMs: parsed.activeMs ?? 0,
      lastSteps: parsed.lastSteps ?? parsed.steps ?? 0,
      lastFetchTs: parsed.lastFetchTs ?? Date.now(),
      waterMl: parsed.waterMl ?? 0,
      sleepMin: parsed.sleepMin ?? 0,
      calorieIntakeKcal: parsed.calorieIntakeKcal ?? 0,
    };
  } catch (e) {
    console.log('loadDailyStats error', e);
    return { steps: 0, activeMs: 0, lastSteps: 0, lastFetchTs: Date.now(), waterMl: 0, sleepMin: 0, calorieIntakeKcal: 0 };
  }
}

export async function saveDailyStats(dateKey: string, stats: DailyStats) {
  try {
    await AsyncStorage.setItem(DAILY_PREFIX + dateKey, JSON.stringify(stats));
  } catch (e) {
    console.log('saveDailyStats error', e);
  }
}

export async function setDailySteps(steps: number, dateKey = getTodayKey()) {
  const current = await loadDailyStats(dateKey);
  const next: DailyStats = {
    ...current,
    steps,
    lastSteps: steps,
    lastFetchTs: Date.now(),
    waterMl: current.waterMl ?? 0,
    sleepMin: current.sleepMin ?? 0,
    calorieIntakeKcal: current.calorieIntakeKcal ?? 0,
  };
  await saveDailyStats(dateKey, next);
}

export async function addActiveMs(ms: number, dateKey = getTodayKey()) {
  const current = await loadDailyStats(dateKey);
  const next: DailyStats = {
    ...current,
    activeMs: Math.max(0, (current.activeMs || 0) + ms),
    lastFetchTs: Date.now(),
    waterMl: current.waterMl ?? 0,
    sleepMin: current.sleepMin ?? 0,
    calorieIntakeKcal: current.calorieIntakeKcal ?? 0,
  };
  await saveDailyStats(dateKey, next);
}

export async function getActiveMsToday(dateKey = getTodayKey()): Promise<number> {
  const stats = await loadDailyStats(dateKey);
  return stats.activeMs || 0;
}

export async function getTodaySteps(dateKey = getTodayKey()): Promise<number> {
  const stats = await loadDailyStats(dateKey);
  return stats.steps || 0;
}

export async function updateStepsAndActiveEstimate(steps: number, nowTs = Date.now(), dateKey = getTodayKey()) {
  // If steps increased since last fetch, we assume the elapsed time was "active".
  const current = await loadDailyStats(dateKey);
  const stepDelta = steps - (current.lastSteps || 0);
  let addMs = 0;
  if (stepDelta > 0) {
    const deltaMs = Math.max(0, nowTs - (current.lastFetchTs || nowTs));
    // Cap the add to avoid huge jumps if device wakes after long time.
    addMs = Math.min(deltaMs, 15 * 60 * 1000);
  }
  const next: DailyStats = {
    steps,
    activeMs: Math.max(0, (current.activeMs || 0) + addMs),
    lastSteps: steps,
    lastFetchTs: nowTs,
    waterMl: current.waterMl ?? 0,
    sleepMin: current.sleepMin ?? 0,
    calorieIntakeKcal: current.calorieIntakeKcal ?? 0,
  };
  await saveDailyStats(dateKey, next);
}

export async function logExercise(item: Omit<ExerciseLogItem, 'id' | 'timestamp'> & Partial<Pick<ExerciseLogItem, 'timestamp'>>) {
  try {
    const raw = await AsyncStorage.getItem(EXERCISE_LOGS_KEY);
    const arr: ExerciseLogItem[] = raw ? JSON.parse(raw) : [];
    const toAdd: ExerciseLogItem = {
      id: `${Date.now()}_${Math.random().toString(36).slice(2)}`,
      type: item.type,
      reps: item.reps ?? null,
      durationMs: item.durationMs ?? null,
      timestamp: item.timestamp ?? Date.now(),
    };
    arr.unshift(toAdd);
    await AsyncStorage.setItem(EXERCISE_LOGS_KEY, JSON.stringify(arr.slice(0, 200))); // keep last 200
  } catch (e) {
    console.log('logExercise error', e);
  }
}

export async function getExerciseLogs(): Promise<ExerciseLogItem[]> {
  try {
    const raw = await AsyncStorage.getItem(EXERCISE_LOGS_KEY);
    return raw ? (JSON.parse(raw) as ExerciseLogItem[]) : [];
  } catch (e) {
    console.log('getExerciseLogs error', e);
    return [];
  }
}

// Wellness trackers helpers
export async function addWaterMl(amount: number, dateKey = getTodayKey()) {
  const current = await loadDailyStats(dateKey);
  const next: DailyStats = {
    ...current,
    waterMl: Math.max(0, (current.waterMl ?? 0) + amount),
    lastFetchTs: Date.now(),
  };
  await saveDailyStats(dateKey, next);
}

export async function setWaterMl(value: number, dateKey = getTodayKey()) {
  const current = await loadDailyStats(dateKey);
  const next: DailyStats = { ...current, waterMl: Math.max(0, value), lastFetchTs: Date.now() };
  await saveDailyStats(dateKey, next);
}

export async function addSleepMin(amount: number, dateKey = getTodayKey()) {
  const current = await loadDailyStats(dateKey);
  const next: DailyStats = {
    ...current,
    sleepMin: Math.max(0, (current.sleepMin ?? 0) + amount),
    lastFetchTs: Date.now(),
  };
  await saveDailyStats(dateKey, next);
}

export async function setSleepMin(value: number, dateKey = getTodayKey()) {
  const current = await loadDailyStats(dateKey);
  const next: DailyStats = { ...current, sleepMin: Math.max(0, value), lastFetchTs: Date.now() };
  await saveDailyStats(dateKey, next);
}

export async function addCalorieIntake(kcal: number, dateKey = getTodayKey()) {
  const current = await loadDailyStats(dateKey);
  const next: DailyStats = {
    ...current,
    calorieIntakeKcal: Math.max(0, (current.calorieIntakeKcal ?? 0) + kcal),
    lastFetchTs: Date.now(),
  };
  await saveDailyStats(dateKey, next);
}

export async function setCalorieIntakeKcal(value: number, dateKey = getTodayKey()) {
  const current = await loadDailyStats(dateKey);
  const next: DailyStats = { ...current, calorieIntakeKcal: Math.max(0, value), lastFetchTs: Date.now() };
  await saveDailyStats(dateKey, next);
}

// Clear all persisted activity-related data (daily stats and exercise logs)
export async function clearAllActivityData() {
  try {
    const keys = await AsyncStorage.getAllKeys();
    const toRemove = keys.filter((k) => k === EXERCISE_LOGS_KEY || k.startsWith(DAILY_PREFIX));
    if (toRemove.length) {
      await AsyncStorage.multiRemove(toRemove);
      console.log('Cleared activity data keys:', toRemove.length);
    } else {
      console.log('No activity data keys to clear');
    }
  } catch (e) {
    console.log('clearAllActivityData error', e);
  }
}
